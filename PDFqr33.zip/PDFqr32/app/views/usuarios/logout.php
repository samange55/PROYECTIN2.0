<?php
session_start();
session_unset();
session_destroy();

// Redirigir al login usando el router
header("Location: /PDFqr30/index.php?url=login");
exit;
