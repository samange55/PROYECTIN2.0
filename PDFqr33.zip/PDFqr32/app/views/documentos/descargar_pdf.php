<?php
session_start();
include "config/config.php";

// 🔹 Definir la ruta de fuentes
if (!defined('FPDF_FONTPATH')) {
    define('FPDF_FONTPATH', __DIR__ . '/../../../lib/FPDF/font/');
}

// 🔹 Incluir librerías
require_once __DIR__ . '/../../../lib/FPDF/fpdf.php';
require_once __DIR__ . '/../../../lib/FPDI/src/autoload.php';

use setasign\Fpdi\Fpdi;

// Verificar login
if (!isset($_SESSION["usuario"])) {
    header("Location: index.php?url=login");
    exit;
}

if (!isset($_GET["id"])) {
    die("Falta el ID del documento.");
}

$id = $_GET["id"];

// Obtener datos de la BD
$sql = "SELECT * FROM QRdocumentos WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $id);
$stmt->execute();
$result = $stmt->get_result();
$doc = $result->fetch_assoc();

if (!$doc) {
    die("Documento no encontrado.");
}

// Seleccionar plantilla según tipo_documento
$plantilla = __DIR__ . "/../../../plantillas/no_adeudo.pdf";
if ($doc["tipo_documento"] === "aportacion_mejoras") {
    $plantilla = __DIR__ . "/../../../plantillas/aportacion_mejoras.pdf";
}

// Crear PDF usando la plantilla
$pdf = new Fpdi();
$pdf->AddPage();
$pdf->setSourceFile($plantilla);
$tplIdx = $pdf->importPage(1);
$pdf->useTemplate($tplIdx, 0, 0, 210);

$pdf->SetFont("Arial", "", 12);
$pdf->SetTextColor(0, 0, 0);

// ===============================
// 📌 BLOQUE DE COORDENADAS
// ===============================

// Para documentos de NO ADEUDO
if ($doc["tipo_documento"] === "no_adeudo") {
    // Contribuyente
    $pdf->SetXY(40, 72);
    $pdf->Cell(120, 10, utf8_decode($doc["contribuyente"]), 0, 0);

    // Año fiscal
    $pdf->SetXY(165, 48);
    $pdf->Cell(30, 8, $doc["anio_fiscal"], 0, 0);

    // Folio No Adeudo
    $pdf->SetXY(40, 75);
    $pdf->Cell(60, 8, $doc["folio_no_adeudo"], 0, 0);

    // Clave catastral
    $pdf->SetXY(71, 154.5);
    $pdf->Cell(60, 8, $doc["clave_catastral"], 0, 0);

    // Dirección
    $pdf->SetXY(40, 145);
    $pdf->Cell(120, 8, utf8_decode($doc["direccion"]), 0, 0);

    // Tipo de Predio
    $pdf->SetXY(115, 139.5);
    $pdf->Cell(120, 8, utf8_decode($doc["tipo_predio"]), 0, 0);

    // Colonia
    $pdf->SetXY(40, 106);
    $pdf->Cell(120, 8, utf8_decode($doc["colonia"]), 0, 0);

    // Línea de captura
    $pdf->SetXY(40, 170);
    $pdf->Cell(50, 8, $doc["linea_captura"], 0, 0);

    // Bimestre
    $pdf->SetXY(150, 165);
    $pdf->Cell(40, 8, $doc["bimestre"], 0, 0);

    // Base gravable
    $pdf->SetXY(150, 106);
    $pdf->Cell(40, 8, $doc["base_gravable"], 0, 0);

    // Superficie Terreno
    $pdf->SetXY(40, 175.4);
    $pdf->Cell(40, 8, $doc["superficie_terreno"], 0, 0);

    // Superficie Construcción
    $pdf->SetXY(150, 175);
    $pdf->Cell(40, 8, $doc["superficie_construccion"], 0, 0);

    // Recibo oficial
    $pdf->SetXY(10, 185.5);
    $pdf->Cell(50, 8, $doc["recibo_oficial"], 0, 0);

    // Costo certificación
    $pdf->SetXY(40, 140);
    $pdf->Cell(50, 8, $doc["costo_certificacion"], 0, 0);

    // Subdirector
    $pdf->SetXY(140, 200);
    $pdf->Cell(60, 8, utf8_decode($doc["subdirector"]), 0, 0);

    // Cargo
    $pdf->SetXY(140, 208);
    $pdf->Cell(60, 8, utf8_decode($doc["cargo"]), 0, 0);

    // Fecha de captura
    $pdf->SetXY(150, 150);
    $pdf->Cell(40, 8, $doc["fecha_captura"], 0, 0);
}

// Para documentos de APORTACIÓN A MEJORAS
if ($doc["tipo_documento"] === "aportacion_mejoras") {
    // Contribuyente
    $pdf->SetXY(45, 80);
    $pdf->Cell(120, 10, utf8_decode($doc["contribuyente"]), 0, 0);

    // Clave catastral
    $pdf->SetXY(60, 100);
    $pdf->Cell(60, 8, $doc["clave_catastral"], 0, 0);

    // Dirección
    $pdf->SetXY(45, 115);
    $pdf->Cell(120, 8, utf8_decode($doc["direccion"]), 0, 0);

    // Colonia
    $pdf->SetXY(45, 130);
    $pdf->Cell(120, 8, utf8_decode($doc["colonia"]), 0, 0);

    // Línea de captura
    $pdf->SetXY(45, 145);
    $pdf->Cell(50, 8, $doc["linea_captura"], 0, 0);

    // Recibo mejoras
    $pdf->SetXY(45, 160);
    $pdf->Cell(50, 8, $doc["recibo_mejoras"], 0, 0);

    // Costo certificación
    $pdf->SetXY(45, 175);
    $pdf->Cell(50, 8, $doc["costo_certificacion"], 0, 0);

    // Subdirector
    $pdf->SetXY(140, 200);
    $pdf->Cell(60, 8, utf8_decode($doc["subdirector"]), 0, 0);

    // Cargo
    $pdf->SetXY(140, 208);
    $pdf->Cell(60, 8, utf8_decode($doc["cargo"]), 0, 0);

    // Fecha de captura
    $pdf->SetXY(150, 150);
    $pdf->Cell(40, 8, $doc["fecha_captura"], 0, 0);
}

// ===============================

// Descargar directamente
$pdf->Output("D", ucfirst($doc["tipo_documento"]) . "_" . $doc["id"] . ".pdf");

