<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Captura de Documentos</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f4f4;
        }
        .navbar {
            background-color: #9F2241;
        }
        .navbar-brand, .nav-link, .navbar-text {
            color: #fff !important;
        }
        .card {
            border-radius: 12px;
            box-shadow: 0px 2px 6px rgba(15, 18, 15, 0.1);
        }
        .btn-primary {
            background-color: #BC955C;
            border: none;
        }
        .btn-primary:hover {
            background-color: #a58343ff;
        }
        footer {
            background: #003366;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 30px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
      <img src="IXTALOGO.png" alt="Logo" height="40" class="me-2"> Sistema de Validación de Documentos
    </a>
    <div class="d-flex">
      <?php if (isset($_SESSION["usuario"])) { ?>
        <span class="navbar-text me-3">
          Bienvenido 
        </span>
        <a class="btn btn-light btn-sm" href="logout.php">Cerrar sesión</a>
      <?php } ?>
    </div>
  </div>
</nav>
<div class="container mt-4">
