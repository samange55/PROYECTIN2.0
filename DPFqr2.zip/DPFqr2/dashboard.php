<?php
session_start();
include "config.php";

if (!isset($_SESSION["usuario"])) {
    header("Location: login.php");
    exit;
}

// Función para obtener el id del usuario logueado
function getUserId($usuario, $conn) {
    $sql = "SELECT id FROM QRusuarios WHERE usuario = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        return $row["id"];
    }
    return null;
}

$id_capturista = getUserId($_SESSION["usuario"], $conn);

// Insertar documento si se envía formulario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["guardar_doc"])) {
    $id = uniqid();
    $fecha_captura = date("Y-m-d");
    $folio_no_adeudo = $_POST["folio_no_adeudo"];
    $folio_aportacion = $_POST["folio_aportacion"];
    $tipo_predio = $_POST["tipo_predio"];
    $colonia = $_POST["colonia"];
    $direccion = $_POST["direccion"];
    $contribuyente = $_POST["contribuyente"];
    $clave_catastral = $_POST["clave_catastral"];
    $base_gravable = $_POST["base_gravable"];
    $bimestre = $_POST["bimestre"];
    $tipo_documento = $_POST["tipo_documento"];

    $sql = "INSERT INTO QRdocumentos 
        (id, fecha_captura, id_capturista, folio_no_adeudo, folio_aportacion, 
         tipo_predio, colonia, direccion, contribuyente, clave_catastral, 
         base_gravable, bimestre, tipo_documento) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Error SQL: " . $conn->error);
    }

    $stmt->bind_param(
        "ssissssssssis",
        $id, $fecha_captura, $id_capturista,
        $folio_no_adeudo, $folio_aportacion,
        $tipo_predio, $colonia, $direccion,
        $contribuyente, $clave_catastral,
        $base_gravable, $bimestre, $tipo_documento
    );

    if ($stmt->execute()) {
        $msg = " Documento guardado correctamente";
    } else {
        $error = " Error: " . $conn->error;
    }
}

// Obtener documentos del usuario
$sql = "SELECT * FROM QRdocumentos WHERE id_capturista = ? ORDER BY fecha_captura DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_capturista);
$stmt->execute();
$docs = $stmt->get_result();
?>

<?php include "header.php"; ?>

<div class="row">
  <div class="col-md-6">
    <div class="card p-4 mb-4">
      <h4> Registrar nuevo documento</h4>
      <?php if (isset($msg)) { ?>
        <div class="alert alert-success"><?php echo $msg; ?></div>
      <?php } ?>
      <?php if (isset($error)) { ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
      <?php } ?>
      <form method="post" class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Folio No Adeudo</label>
          <input type="text" name="folio_no_adeudo" class="form-control">
        </div>
        <div class="col-md-6">
          <label class="form-label">Folio Aportación</label>
          <input type="text" name="folio_aportacion" class="form-control">
        </div>
        <div class="col-md-6">
          <label class="form-label">Tipo de predio</label>
          <input type="text" name="tipo_predio" class="form-control">
        </div>
        <div class="col-md-6">
          <label class="form-label">Colonia</label>
          <input type="text" name="colonia" class="form-control">
        </div>
        <div class="col-12">
          <label class="form-label">Dirección</label>
          <input type="text" name="direccion" class="form-control">
        </div>
        <div class="col-md-6">
          <label class="form-label">Contribuyente</label>
          <input type="text" name="contribuyente" class="form-control">
        </div>
        <div class="col-md-6">
          <label class="form-label">Clave catastral</label>
          <input type="text" name="clave_catastral" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Base gravable</label>
          <input type="number" step="0.01" name="base_gravable" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Bimestre</label>
          <input type="number" name="bimestre" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Tipo de documento</label>
          <select name="tipo_documento" class="form-select">
            <option value="no_adeudo">No Adeudo</option>
            <option value="aportacion_mejoras">Aportación Mejoras</option>
          </select>
        </div>
        <div class="col-12">
          <button type="submit" name="guardar_doc" class="btn btn-primary w-100">Guardar documento</button>
        </div>
      </form>
    </div>
  </div>

  <div class="col-md-6">
    <div class="card p-4">
      <h4> Documentos capturados</h4>
      <div class="table-responsive">
        <table class="table table-striped align-middle">
          <thead class="table-dark">
            <tr>
              <th>Fecha</th>
              <th>Contribuyente</th>
              <th>Clave</th>
              <th>Tipo</th>
            </tr>
          </thead>
          <tbody>
          <?php while ($row = $docs->fetch_assoc()) { ?>
            <tr>
              <td><?php echo $row["fecha_captura"]; ?></td>
              <td><?php echo $row["contribuyente"]; ?></td>
              <td><?php echo $row["clave_catastral"]; ?></td>
              <td>
                <span class="badge bg-<?php echo $row["tipo_documento"] == 'no_adeudo' ? 'success' : 'warning'; ?>">
                  <?php echo $row["tipo_documento"]; ?>
                </span>
              </td>
            </tr>
          <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>


