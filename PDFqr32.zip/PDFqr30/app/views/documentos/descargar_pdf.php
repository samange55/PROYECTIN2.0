<?php
session_start();
include "config/config.php";

// 🔹 Definir la ruta de fuentes
if (!defined('FPDF_FONTPATH')) {
    define('FPDF_FONTPATH', __DIR__ . '/../../../lib/FPDF/font/');
}

// 🔹 Incluir librerías
require_once __DIR__ . '/../../../lib/FPDF/fpdf.php';
require_once __DIR__ . '/../../../lib/FPDI/src/autoload.php';

use setasign\Fpdi\Fpdi;

// Verificar login
if (!isset($_SESSION["usuario"])) {
    header("Location: index.php?url=login");
    exit;
}

if (!isset($_GET["id"])) {
    die("Falta el ID del documento.");
}

$id = $_GET["id"];

// Obtener datos de la BD
$sql = "SELECT * FROM QRdocumentos WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $id);
$stmt->execute();
$result = $stmt->get_result();
$doc = $result->fetch_assoc();

if (!$doc) {
    die("Documento no encontrado.");
}

// Seleccionar plantilla según tipo_documento
$plantilla = __DIR__ . "/../../../plantillas/no_adeudo.pdf";
if ($doc["tipo_documento"] === "aportacion_mejoras") {
    $plantilla = __DIR__ . "/../../../plantillas/aportacion_mejoras.pdf";
}

// Crear PDF usando la plantilla
$pdf = new Fpdi();
$pdf->AddPage();
$pdf->setSourceFile($plantilla);
$tplIdx = $pdf->importPage(1);
$pdf->useTemplate($tplIdx, 0, 0, 210);

$pdf->SetFont("Arial", "", 12);
$pdf->SetTextColor(0, 0, 0);

// === Colocar datos (ejemplo) ===
$pdf->SetXY(50, 80);
$pdf->Cell(100, 10, utf8_decode($doc["contribuyente"]), 0, 0);

$pdf->SetXY(50, 95);
$pdf->Cell(100, 10, $doc["clave_catastral"], 0, 0);

$pdf->SetXY(50, 110);
$pdf->Cell(100, 10, $doc["folio_no_adeudo"], 0, 0);

$pdf->SetXY(50, 125);
$pdf->Cell(100, 10, $doc["fecha_captura"], 0, 0);

// Descargar directamente
$pdf->Output("D", ucfirst($doc["tipo_documento"]) . "_" . $doc["id"] . ".pdf");
