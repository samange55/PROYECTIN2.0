<?php
// Funciones auxiliares
