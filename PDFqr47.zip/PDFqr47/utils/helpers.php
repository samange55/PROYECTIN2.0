<?php
// Funciones auxiliares

/**
 * Construye una URL absoluta para un recurso del sistema.
 * - Si está en localhost, usa la IP LAN definida.
 * - Si está en servidor, usa el host detectado.
 */
function buildAbsoluteUrl($path = '', $params = [])
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';

    //  Cambia esta IP por la de tu máquina si usas LAN
    if ($host === 'localhost' || $host === '127.0.0.1') {
        $host = '192.168.100.35';
    }

    // Ruta base del proyecto
    $scriptName = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
    $base = rtrim($scriptName, '/');

    $url = $scheme . '://' . $host . $base . '/' . ltrim($path, '/');

    if (!empty($params)) {
        $url .= '?' . http_build_query($params);
    }

    return $url;
}
