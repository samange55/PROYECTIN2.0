-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-09-2025 a las 17:49:22
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistema_qr`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `qrdocumentos`
--

CREATE TABLE `qrdocumentos` (
  `id` char(36) NOT NULL,
  `fecha_captura` date NOT NULL,
  `id_capturista` int(11) NOT NULL,
  `folio_no_adeudo` varchar(50) DEFAULT NULL,
  `folio_aportacion` varchar(50) DEFAULT NULL,
  `subdirector` varchar(100) DEFAULT '1',
  `cargo` varchar(100) DEFAULT 'Subdirector de Recaudación',
  `anio_fiscal` int(11) DEFAULT 2025,
  `tipo_predio` varchar(50) DEFAULT NULL,
  `colonia` varchar(100) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `contribuyente` varchar(100) DEFAULT NULL,
  `clave_catastral` varchar(50) DEFAULT NULL,
  `base_gravable` decimal(12,2) DEFAULT NULL,
  `bimestre` int(11) DEFAULT NULL,
  `linea_captura` varchar(100) DEFAULT NULL,
  `superficie_terreno` decimal(10,2) DEFAULT NULL,
  `superficie_construccion` decimal(10,2) DEFAULT NULL,
  `recibo_oficial` varchar(50) DEFAULT NULL,
  `recibo_mejoras` varchar(50) DEFAULT NULL,
  `costo_certificacion` decimal(10,2) DEFAULT NULL,
  `tipo_documento` enum('no_adeudo','aportacion_mejoras') DEFAULT NULL,
  `ruta_pdf` varchar(255) DEFAULT NULL,
  `url_validacion` varchar(255) DEFAULT NULL,
  `estado_pdf` enum('activo','cancelado') DEFAULT 'activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `qrdocumentos`
--

INSERT INTO `qrdocumentos` (`id`, `fecha_captura`, `id_capturista`, `folio_no_adeudo`, `folio_aportacion`, `subdirector`, `cargo`, `anio_fiscal`, `tipo_predio`, `colonia`, `direccion`, `contribuyente`, `clave_catastral`, `base_gravable`, `bimestre`, `linea_captura`, `superficie_terreno`, `superficie_construccion`, `recibo_oficial`, `recibo_mejoras`, `costo_certificacion`, `tipo_documento`, `ruta_pdf`, `url_validacion`, `estado_pdf`) VALUES
('68d22c1bac4e5', '2025-09-22', 1, '789456', 'NA-2025-25555', '0', 'Subdirector de Recaudación', 2025, 'Construido', 'Ampliación Dr. Jorge Jiménez Cantú', 'av hidalgo', 'chester bennington', '789', 7586.00, 5, '152', 7896.00, 520.00, '7863', '489', 156.00, 'no_adeudo', NULL, NULL, 'activo'),
('68d22c4d79697', '2025-09-18', 1, '789456', 'NA-2025-25555', '0', 'Subdirector de Recaudación', 2025, 'Baldío', 'El Pilar', 'av hidalgo', 'jose jose', '789', 7586.00, 6, '152', 7896.00, 520.00, '7863', '489', 156.00, 'aportacion_mejoras', NULL, NULL, 'activo'),
('68d23913e4eae', '2025-09-19', 1, 'NA-2025-2255555', 'NA-2025-25555', '0', 'Subdirector de Recaudación', 2025, 'Construido', '1ro de Mayo', 'av hidalgo', 'manuel', '789', 7586.00, 1, '152', 7896.00, 520.00, '7863', '489', 156.00, 'no_adeudo', NULL, NULL, 'activo'),
('68d2bcec51106', '2025-09-16', 1, '789456', 'NA-2025-25555', '0', 'Subdirector de Recaudación', 2025, 'Sin construir', 'Ampliación Plutarco Elías Calles', 'av hidalgo', 'robin', '789', 7586.00, 4, '152', 7896.00, 520.00, '7863', '489', 156.00, 'aportacion_mejoras', NULL, NULL, 'activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `qrusuarios`
--

CREATE TABLE `qrusuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `rol` varchar(20) DEFAULT 'capturista'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `qrusuarios`
--

INSERT INTO `qrusuarios` (`id`, `usuario`, `password`, `nombre`, `rol`) VALUES
(1, 'admin', '$2y$10$tRSfxo7E90yMlAO34CFBNuHRQHbjjS/LWoQKh1xJY5PCv2nWvV..S', 'emiliano', 'capturista');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `qrdocumentos`
--
ALTER TABLE `qrdocumentos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_capturista` (`id_capturista`);

--
-- Indices de la tabla `qrusuarios`
--
ALTER TABLE `qrusuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `qrusuarios`
--
ALTER TABLE `qrusuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `qrdocumentos`
--
ALTER TABLE `qrdocumentos`
  ADD CONSTRAINT `qrdocumentos_ibfk_1` FOREIGN KEY (`id_capturista`) REFERENCES `qrusuarios` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
