<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "config.php";

// Verificar usuario
if (!isset($_SESSION["usuario"])) {
    header("Location: login.php");
    exit;
}

// Librería PhpSpreadsheet
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;

$usuario = $_SESSION["usuario"];
$sqlUser = "SELECT id FROM QRusuarios WHERE usuario = ?";
$stmtUser = $conn->prepare($sqlUser);
$stmtUser->bind_param("s", $usuario);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();
$id_capturista = ($row = $resultUser->fetch_assoc()) ? $row["id"] : 0;

// =======================
// Filtros iguales a documentos.php
// =======================
$condiciones = [];
$params = [];
$tipos = "";

if (!empty($_GET["folio_no_adeudo"])) {
    $condiciones[] = "folio_no_adeudo LIKE ?";
    $params[] = "%".$_GET["folio_no_adeudo"]."%";
    $tipos .= "s";
}
if (!empty($_GET["folio_aportacion"])) {
    $condiciones[] = "folio_aportacion LIKE ?";
    $params[] = "%".$_GET["folio_aportacion"]."%";
    $tipos .= "s";
}
if (!empty($_GET["clave_catastral"])) {
    $condiciones[] = "clave_catastral LIKE ?";
    $params[] = "%".$_GET["clave_catastral"]."%";
    $tipos .= "s";
}
if (!empty($_GET["contribuyente"])) {
    $condiciones[] = "contribuyente LIKE ?";
    $params[] = "%".$_GET["contribuyente"]."%";
    $tipos .= "s";
}

// =======================
// Query con filtros
// =======================
$sqlDocs = "SELECT id, fecha_captura, contribuyente, folio_no_adeudo, folio_aportacion, clave_catastral, tipo_documento 
            FROM QRdocumentos 
            WHERE id_capturista = ?";

$tipos = "i".$tipos;
array_unshift($params, $id_capturista);

if (!empty($condiciones)) {
    $sqlDocs .= " AND " . implode(" AND ", $condiciones);
}

$sqlDocs .= " ORDER BY fecha_captura DESC";

$stmtDocs = $conn->prepare($sqlDocs);
$stmtDocs->bind_param($tipos, ...$params);
$stmtDocs->execute();
$docs = $stmtDocs->get_result();

// =======================
// Crear Excel
// =======================
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Encabezados
$encabezados = ['ID','Fecha','Contribuyente','Folio No adeudo','Folio Aportación','Clave Catastral','Tipo Documento'];
$col = 'A';
foreach ($encabezados as $header) {
    $sheet->setCellValue($col.'1', $header);
    $col++;
}

// Estilos de encabezados
$sheet->getStyle('A1:G1')->getFont()->setBold(true);
$sheet->getStyle('A1:G1')->getFill()
      ->setFillType(Fill::FILL_SOLID)
      ->getStartColor()->setARGB('FFFFD700'); // Amarillo

// Contenido
$rowNum = 2;
if ($docs->num_rows > 0) {
    while ($row = $docs->fetch_assoc()) {
        // Traducir tipo_documento
        $tipoDoc = $row['tipo_documento'] == 'no_adeudo' ? 'No adeudo predial' : 'Aportación a mejoras';

        $sheet->setCellValue('A'.$rowNum, $row['id']);
        $sheet->setCellValue('B'.$rowNum, $row['fecha_captura']);
        $sheet->setCellValue('C'.$rowNum, $row['contribuyente']);
        $sheet->setCellValue('D'.$rowNum, $row['folio_no_adeudo']);
        $sheet->setCellValue('E'.$rowNum, $row['folio_aportacion']);
        $sheet->setCellValue('F'.$rowNum, $row['clave_catastral']);
        $sheet->setCellValue('G'.$rowNum, $tipoDoc);
        $rowNum++;
    }
} else {
    $sheet->setCellValue('A2', 'No hay documentos que coincidan con el filtro');
}

// Autoajustar ancho de columnas
foreach (range('A', 'G') as $col) {
    $sheet->getColumnDimension($col)->setAutoSize(true);
}

// =======================
// Descargar Excel
// =======================
$filename = "documentos_exportados_".date("Y-m-d_H-i-s").".xlsx";
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header("Content-Disposition: attachment; filename=\"$filename\"");
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
