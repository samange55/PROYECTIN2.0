<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "config.php";

// Verificar usuario
if (!isset($_SESSION["usuario"])) {
    header("Location: login.php");
    exit;
}

// Obtener id del capturista logueado
$usuario = $_SESSION["usuario"];
$sqlUser = "SELECT id FROM QRusuarios WHERE usuario = ?";
$stmtUser = $conn->prepare($sqlUser);
$stmtUser->bind_param("s", $usuario);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();
$id_capturista = ($row = $resultUser->fetch_assoc()) ? $row["id"] : 0;

if (isset($_GET["id"])) {
    $id_doc = $_GET["id"];

    // Verificar que el documento pertenezca al usuario logueado
    $sqlCheck = "SELECT id FROM QRdocumentos WHERE id = ? AND id_capturista = ?";
    $stmtCheck = $conn->prepare($sqlCheck);
    $stmtCheck->bind_param("si", $id_doc, $id_capturista);
    $stmtCheck->execute();
    $resCheck = $stmtCheck->get_result();

    if ($resCheck->num_rows > 0) {
        // Eliminar registro
        $sqlDel = "DELETE FROM QRdocumentos WHERE id = ? AND id_capturista = ?";
        $stmtDel = $conn->prepare($sqlDel);
        $stmtDel->bind_param("si", $id_doc, $id_capturista);

        if ($stmtDel->execute()) {
            $_SESSION["msg"] = "Documento eliminado correctamente.";
        } else {
            $_SESSION["error"] = "Error al eliminar el documento: " . $conn->error;
        }
    } else {
        $_SESSION["error"] = "No se encontró el documento o no tienes permisos.";
    }
}

// Redirigir a documentos.php
header("Location: documentos.php");
exit;
