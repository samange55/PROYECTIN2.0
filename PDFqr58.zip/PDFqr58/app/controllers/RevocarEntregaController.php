<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include_once dirname(__DIR__, 2) . "/config/config.php";
require_once dirname(__DIR__, 2) . "/utils/helpers.php";

// ==========================
//  Validar sesión
// ==========================
if (!isset($_SESSION["usuario"])) {
    header("Location: index.php?url=login");
    exit;
}

$usuario = $_SESSION["usuario"];

// ==========================
//  Obtener ID de usuario
// ==========================
$sqlUser = "SELECT id FROM usuarios WHERE usuario = ?";
$stmtUser = $conn->prepare($sqlUser);
$stmtUser->bind_param("s", $usuario);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();
$id_usuario = ($row = $resultUser->fetch_assoc()) ? $row["id"] : 0;

// ==========================
//  Validar permiso
// ==========================
if (!tienePermiso($conn, $id_usuario, "puede_revocar_entrega")) {
    die("<div style='text-align:center;margin-top:50px;font-family:Arial;'>
            <h3 style='color:red;'> No tienes permiso para revocar entregas.</h3>
            <a href='index.php?url=documentos' style='color:#9F2241;'>Regresar</a>
        </div>");
}

// ==========================
//  Validar ID
// ==========================
if ($_SERVER["REQUEST_METHOD"] !== "POST" || empty($_POST["id"])) {
    header("Location: index.php?url=documentos");
    exit;
}

$id = $_POST["id"];

// ==========================
//  Actualizar estado
// ==========================
$sql = "UPDATE documentos SET estado_entrega = 'pendiente' WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $id);

if ($stmt->execute()) {
    $_SESSION["msg_success"] = "Entrega revocada correctamente.";
} else {
    $_SESSION["msg_error"] = "Error al revocar la entrega: " . $conn->error;
}

// --- Registrar movimiento ---
registrarHistorialAuto($conn, 'Revocar Entrega', "El usuario {$usuario} revocó el documento con ID {$id}.");


header("Location: index.php?url=documentos");
exit;
