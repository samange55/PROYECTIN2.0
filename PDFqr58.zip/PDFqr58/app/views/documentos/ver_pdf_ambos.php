<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "config/config.php";
require_once __DIR__ . '/../../../utils/helpers.php';

if (!defined('FPDF_FONTPATH')) {
    define('FPDF_FONTPATH', __DIR__ . '/../../../lib/fpdf/font/');
}
require_once __DIR__ . '/../../../lib/fpdf/fpdf.php';
require_once __DIR__ . '/../../../lib/fpdi/src/autoload.php';
require_once __DIR__ . '/../../../lib/phpqrcode/qrlib.php';

use setasign\Fpdi\Fpdi;

// ======================================================
//  ACCESO PÚBLICO
// ======================================================
// (no se requiere iniciar sesión para ver los PDFs)

// ======================================================
//  VALIDAR PARÁMETROS
// ======================================================
if (!isset($_GET["id1"]) || !isset($_GET["id2"])) {
    die("Faltan parámetros id1 e id2.");
}

$ids = [$_GET["id1"], $_GET["id2"]];

// ======================================================
//  FUNCIÓN PARA RENDERIZAR CADA DOCUMENTO
// ======================================================
function renderDocumento($pdf, $doc, $conn)
{
    // --- Limpiar ceros decimales ---
    foreach (["superficie_terreno", "superficie_construccion", "costo_certificacion", "base_gravable"] as $campo) {
        if (isset($doc[$campo])) {
            $doc[$campo] = rtrim(rtrim($doc[$campo], '0'), '.');
        } else {
            $doc[$campo] = "";
        }
    }

    // --- Generar QR ---
    $urlQR = buildAbsoluteUrl("index.php", [
        "url" => "ver_pdf",
        "id"  => $doc["id"]
    ]);

    $tmpQR = tempnam(sys_get_temp_dir(), 'qr_') . '.png';
    QRcode::png($urlQR, $tmpQR, QR_ECLEVEL_M, 6, 2);

    // --- Validar QR ---
    if (!file_exists($tmpQR) || filesize($tmpQR) <= 0) {
        error_log("⚠️ Error generando QR para ID: " . $doc["id"]);
        return;
    }

    // --- Plantilla según tipo ---
    $plantilla = __DIR__ . "/../../../plantillas/no_adeudo.pdf";
    if ($doc["tipo_documento"] === "aportacion_mejoras") {
        $plantilla = __DIR__ . "/../../../plantillas/aportacion_mejoras.pdf";
    }

    // --- Nueva página ---
    $pdf->AddPage();
    $pdf->setSourceFile($plantilla);
    $tplIdx = $pdf->importPage(1);
    $pdf->useTemplate($tplIdx, 0, 0, 210);

    $pdf->SetFont("Arial", "", 12);
    $pdf->SetTextColor(0, 0, 0);

    // --- Fecha ---
    $fechaGeneracion = new DateTime($doc["fecha_captura"]);
    $dia  = $fechaGeneracion->format("d");
    $anio = $fechaGeneracion->format("Y");
    $meses = [
        "01" => "ENERO", "02" => "FEBRERO", "03" => "MARZO",
        "04" => "ABRIL", "05" => "MAYO", "06" => "JUNIO",
        "07" => "JULIO", "08" => "AGOSTO", "09" => "SEPTIEMBRE",
        "10" => "OCTUBRE", "11" => "NOVIEMBRE", "12" => "DICIEMBRE"
    ];
    $mes = $meses[$fechaGeneracion->format("m")];

    // ======================================================
    //  BLOQUE: NO ADEUDO
    // ======================================================
    if ($doc["tipo_documento"] === "no_adeudo") {
        $pdf->SetFont("Arial", "", 12);
        $pdf->SetXY(40, 144);
        $pdf->Cell(120, 10, utf8_decode($doc["contribuyente"]), 0, 0);

        $pdf->SetFont("Arial", "", 12);               
        $pdf->SetXY(120, 135);                        
        $tipoPredio = isset($doc["tipo_predio"]) ? mb_strtoupper($doc["tipo_predio"], "UTF-8") : "";
        $pdf->Cell(55, 8, utf8_decode($tipoPredio), 0, 0, "L");

        $pdf->SetFont("Arial", "B", 14);
        $pdf->SetTextColor(255, 0, 0);
        $pdf->SetXY(165, 50.5);
        $pdf->Cell(40, 10, " " . $doc["folio_no_adeudo"], 0, 0);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetFont("Arial", "", 12);
        $pdf->SetXY(150, 160.5);
        $pdf->Cell(30, 8, $doc["anio_fiscal"], 0, 0);
        $pdf->SetXY(40, 89);
        $pdf->Cell(30, 8, $doc["anio_fiscal"], 0, 0);
        $pdf->SetXY(65, 150);
        $pdf->Cell(60, 8, $doc["clave_catastral"], 0, 0);
        $pdf->SetFont('Arial', '', 8);
        $pdf->SetXY(18, 141.5);
        $pdf->MultiCell(150, 6, utf8_decode($doc["direccion"] . " " . $doc["colonia"]), 0, 'L');
        $pdf->SetFont("Arial", "", 9);
        $pdf->SetXY(18, 160.5);
        $pdf->Cell(40, 8, formateaNumeroPlano($doc["base_gravable"]), 0, 0);
        $pdf->SetXY(95, 160.5);
        $pdf->Cell(40, 8, $doc["bimestre"], 0, 0);
        $pdf->SetXY(40, 165);
        $pdf->Cell(50, 8, $doc["linea_captura"], 0, 0);
        $pdf->SetXY(40, 170);
        $pdf->Cell(40, 8, utf8_decode(formateaNumeroPlano($doc["superficie_terreno"]) . " MTS"), 0, 0);
        $pdf->SetXY(150, 170);
        $pdf->Cell(40, 8, utf8_decode(formateaNumeroPlano($doc["superficie_construccion"]) . " MTS"), 0, 0);
        $pdf->SetXY(10, 180);
        $pdf->Cell(50, 8, utf8_decode("HAIX " . $doc["recibo_oficial"]), 0, 0);
        $pdf->SetXY(143, 180);
        $pdf->Cell(50, 8, '$' . formateaNumeroPlano($doc["costo_certificacion"]), 0, 0);
        $pdf->SetXY(40, 68.5);
        $pdf->Cell(60, 8, utf8_decode($doc["subdirector"]), 0, 0);
        $pdf->SetXY(40, 74);
        $pdf->Cell(60, 8, utf8_decode($doc["cargo"]), 0, 0);
        $pdf->SetXY(120, 165);
        $pdf->Cell(60, 8, date('d/m/Y', strtotime($doc["fecha_expedicion_pago"])), 0, 0);

        //las coordenadas de la derecha son para acomodar horizontalmente//
        //las coordenadas de la izquierda son para acomodar verticalmente//
        $pdf->SetXY(67, 213);
        $pdf->Cell(15, 8, $dia, 0, 0);
        $pdf->SetFont("Arial", "", 7);
        $pdf->SetXY(118, 213.5); 
        $pdf->Cell(40, 8, $mes, 0, 0);
        $pdf->SetFont("Arial", "", 12);
        $pdf->SetXY(150, 213);
        $pdf->Cell(20, 8, $anio, 0, 0);
    }

    // ======================================================
    //  BLOQUE: APORTACIÓN MEJORAS
    // ======================================================
    if ($doc["tipo_documento"] === "aportacion_mejoras") {
        // Contribuyente (normal)
        $pdf->SetFont("Arial", "", 12);
        $pdf->SetXY(45, 139.5);
        $pdf->Cell(120, 10, utf8_decode($doc["contribuyente"]), 0, 0);

        // Folio (rojo y en negritas)
        $pdf->SetFont("Arial", "B", 14);
        $pdf->SetTextColor(255, 0, 0);
        $pdf->SetXY(166, 50.5);
        $pdf->Cell(40, 10, " " . $doc["folio_aportacion"], 0, 0);

        // Volver a negro y a fuente NORMAL antes de datos
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetFont("Arial", "", 12);

        // Año fiscal (normal)
        $pdf->SetXY(35, 89.5);
        $pdf->Cell(30, 8, $doc["anio_fiscal"], 0, 0);

        // Clave catastral (normal)
        $pdf->SetFont("Arial", "", 12);
        $pdf->SetXY(128, 135.5);
        $pdf->Cell(80, 8, $doc["clave_catastral"], 0, 0);

        // Dirección (texto pequeño)
        $pdf->SetFont('Arial', '', 8);
        $pdf->SetXY(82, 131.5);
        $pdf->MultiCell(150, 6, utf8_decode($doc["direccion"] . " " . $doc["colonia"]), 0, 'L');

        // Resto (normal)
        $pdf->SetFont("Arial", "", 12);
        $pdf->SetXY(25, 188.5);
        $pdf->Cell(50, 8, utf8_decode("HAIX " . $doc["recibo_oficial"]), 0, 0);

        $pdf->SetXY(25, 194);
        $pdf->Cell(50, 8, '$' . formateaNumeroPlano($doc["costo_certificacion"]), 0, 0);

        $pdf->SetXY(35, 69.5);
        $pdf->Cell(60, 8, utf8_decode($doc["subdirector"]), 0, 0);

        $pdf->SetXY(35, 74.5);
        $pdf->Cell(60, 8, utf8_decode($doc["cargo"]), 0, 0);

        //las coordenadas de la derecha son para acomodar horizontalmente//
        //las coordenadas de la izquierda son para acomodar verticalmente//
        $pdf->SetXY(67, 213);
        $pdf->Cell(15, 8, $dia, 0, 0);
        $pdf->SetFont("Arial", "", 7);
        $pdf->SetXY(118, 213.5); 
        $pdf->Cell(40, 8, $mes, 0, 0);
        $pdf->SetFont("Arial", "", 12);
        $pdf->SetXY(150, 213);
        $pdf->Cell(20, 8, $anio, 0, 0);
    }
    // --- Insertar QR ---
    $pdf->Image($tmpQR, 170, 225, 28, 28);
    unlink($tmpQR);
}

// ======================================================
//  GENERAR PDF FINAL
// ======================================================
$pdf = new Fpdi();

foreach ($ids as $id) {
    $sql = "SELECT d.*, 
               p.tipo_predio, p.colonia, p.direccion, p.contribuyente, p.clave_catastral,
               p.superficie_terreno, p.superficie_construccion,
               pa.base_gravable, pa.bimestre, pa.linea_captura,
               pa.recibo_oficial, pa.recibo_mejoras, pa.costo_certificacion,
               a.nombre AS subdirector, a.cargo
        FROM documentos d
        LEFT JOIN predios p ON d.id = p.documento_id
        LEFT JOIN pagos pa ON d.id = pa.documento_id
        LEFT JOIN autoridades a ON d.autoridad_id = a.id
        WHERE d.id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $doc = $stmt->get_result()->fetch_assoc();

    if ($doc && (!isset($doc["estado_pdf"]) || $doc["estado_pdf"] !== "cancelado")) {
        renderDocumento($pdf, $doc, $conn);
    }
}

// ======================================================
//  SALIDA
// ======================================================
header("Content-Type: application/pdf");
header("Content-Disposition: inline; filename=Ambos_Documentos.pdf");
$pdf->Output("I", "Ambos_Documentos.pdf");
exit;
