<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de Administración</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background-color: #f4f4f4; font-family: Arial, sans-serif; }
        .navbar { background-color: #9F2241; }
        .navbar-brand, .nav-link, .navbar-text { color: #fff !important; }
        .card { border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .card-header { background-color: #9F2241; color: white; font-weight: bold; }
        .table th { background-color: #9F2241; color: white; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Panel de Administración</a>
    <ul class="navbar-nav ms-auto">
      <li class="nav-item"><a href="index.php?url=logout" class="nav-link">Cerrar sesión</a></li>
    </ul>
  </div>
</nav>

<div class="container my-4">
  <h3 class="mb-4">Dashboard General</h3>

  <!-- Tarjetas de conteo -->
  <div class="row text-center mb-4">
    <div class="col-md-2"><div class="card"><div class="card-body"><h5>Total Documentos</h5><h2><?= $totalDocumentos ?></h2></div></div></div>
    <div class="col-md-2"><div class="card"><div class="card-body"><h5>Activos</h5><h2><?= $documentosActivos ?></h2></div></div></div>
    <div class="col-md-2"><div class="card"><div class="card-body"><h5>Cancelados</h5><h2><?= $documentosCancelados ?></h2></div></div></div>
    <div class="col-md-2"><div class="card"><div class="card-body"><h5>Entregados</h5><h2><?= $documentosEntregados ?></h2></div></div></div>
    <div class="col-md-2"><div class="card"><div class="card-body"><h5>Pendientes</h5><h2><?= $documentosPendientes ?></h2></div></div></div>
  </div>

  <!-- Usuarios -->
  <div class="card mb-4">
    <div class="card-header">Gestión de Capturistas</div>
    <div class="card-body">
      <table class="table table-striped text-center align-middle">
  <thead>
    <tr>
      <th>Usuario</th>
      <th>Nombre</th>
      <th>Rol</th>
      <th>Estado</th>
      <th>Ver / Descargar</th> 
      <th>Editar</th>
      <th>Cancelar</th>
      <th>Recuperar Cancelado</th>
      <th>Entregar</th>
      <th>Revocar Entrega</th>
    </tr>
  </thead>
  <tbody>
    <?php while ($u = $usuarios->fetch_assoc()): ?>
    <tr>
      <td><?= htmlspecialchars($u['usuario']) ?></td>
      <td><?= htmlspecialchars($u['nombre']) ?></td>
      <td><?= ucfirst($u['rol']) ?></td>
      <td>
        <span class="badge bg-<?= $u['estado']=='activo'?'success':($u['estado']=='afk'?'warning':'secondary') ?>">
          <?= strtoupper($u['estado']) ?>
        </span>
      </td>

      
      <td>
        <input type="checkbox"
               data-usuario="<?= $u['id'] ?>"
               data-permiso="puede_ver"
               <?= $u['puede_ver'] ? 'checked' : '' ?>>
      </td>

      <td><input type="checkbox" data-usuario="<?= $u['id'] ?>" data-permiso="puede_editar" <?= $u['puede_editar'] ? 'checked' : '' ?>></td>
      <td><input type="checkbox" data-usuario="<?= $u['id'] ?>" data-permiso="puede_cancelar" <?= $u['puede_cancelar'] ? 'checked' : '' ?>></td>
      <td><input type="checkbox" data-usuario="<?= $u['id'] ?>" data-permiso="puede_recuperar" <?= $u['puede_recuperar'] ? 'checked' : '' ?>></td>
      <td><input type="checkbox" data-usuario="<?= $u['id'] ?>" data-permiso="puede_entregar" <?= $u['puede_entregar'] ? 'checked' : '' ?>></td>
      <td><input type="checkbox" data-usuario="<?= $u['id'] ?>" data-permiso="puede_revocar_entrega" <?= $u['puede_revocar_entrega'] ? 'checked' : '' ?>></td>
    </tr>
    <?php endwhile; ?>
  </tbody>
</table>


    </div>
  </div>

  <!-- Historial de acciones -->
  <div class="card">
    <div class="card-header">Historial de movimientos recientes</div>
    <div class="card-body">
      <table class="table table-hover">
        <thead>
          <tr>
            <th>Usuario</th>
            <th>Acción</th>
            <th>Descripción</th>
            <th>Fecha</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($h = $historial->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($h['usuario']) ?></td>
            <td><?= htmlspecialchars($h['accion']) ?></td>
            <td><?= htmlspecialchars($h['descripcion']) ?></td>
            <td><?= $h['fecha'] ?></td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>
<script>
document.querySelectorAll('input[type="checkbox"]').forEach(chk => {
  chk.addEventListener('change', function() {
    const usuario_id = this.getAttribute('data-usuario');
    const permiso = this.getAttribute('data-permiso');
    const valor = this.checked ? 1 : 0;

    fetch('app/controllers/ActualizarPermiso.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `usuario_id=${usuario_id}&permiso=${permiso}&valor=${valor}`
    })
    .then(res => res.text())
    .then(data => console.log(data))
    .catch(err => console.error('Error:', err));
  });
});
</script>

</body>
</html>
