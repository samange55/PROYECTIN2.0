<?php
// ======================================================
// FUNCIONES AUXILIARES GENERALES
// ======================================================

/**
 * Construye una URL absoluta para un recurso del sistema.
 * - Si está en localhost, usa la IP LAN definida.
 * - Si está en servidor, usa el host detectado.
 */
function buildAbsoluteUrl($path = '', $params = [])
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';

    // Cambia esta IP por la de tu máquina si usas LAN
    if ($host === 'localhost' || $host === '127.0.0.1') {
        $host = '192.168.1.72';
    }

    // Ruta base del proyecto
    $scriptName = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
    $base = rtrim($scriptName, '/');

    $url = $scheme . '://' . $host . $base . '/' . ltrim($path, '/');

    if (!empty($params)) {
        $url .= '?' . http_build_query($params);
    }

    return $url;
}

/**
 * Verifica si el usuario tiene permisos globales (puede ver/editar todo).
 */
function tienePermisoGlobal($usuario)
{
    // Lista de usuarios con acceso global
    $usuariosPermitidos = ["admin", "Maciel", "Marisol"];

    return in_array($usuario, $usuariosPermitidos);
}

/**
 * Verifica si un usuario tiene un permiso específico.
 */
function tienePermiso($conn, $usuario_id, $permiso)
{
    $permitidos = [
        "puede_ver", "puede_descargar", "puede_editar", "puede_cancelar",
        "puede_recuperar", "puede_entregar", "puede_revocar_entrega"
    ];

    if (!in_array($permiso, $permitidos)) return false;

    $sql = "SELECT $permiso FROM permisos_usuarios WHERE usuario_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    return isset($result[$permiso]) && $result[$permiso] == 1;
}

// ======================================================
// FORMATEO DE NÚMEROS SIN CEROS DECIMALES
// ======================================================
if (!function_exists('formateaNumeroPlano')) {
    /**
     * Quita ceros decimales y puntos innecesarios, pero deja decimales reales.
     * Ej: 1000.00 → 1000, 1000.50 → 1000.5
     */
    function formateaNumeroPlano($valor)
    {
        if ($valor === null || $valor === '') return '';
        $num = floatval($valor);
        $txt = rtrim(rtrim(number_format($num, 2, '.', ''), '0'), '.');
        return $txt;
    }
}

// ======================================================
// REGISTRO DE HISTORIAL DE MOVIMIENTOS
// ======================================================

/**
 * Registrar una acción en el historial (versión manual)
 *
 * @param mysqli $conn        Conexión activa
 * @param int    $usuario_id  ID del usuario que realizó la acción
 * @param string $accion      Tipo de acción (crear, editar, cancelar, entregar, etc.)
 * @param string $descripcion Descripción detallada
 */
function registrarHistorial($conn, $usuario_id, $accion, $descripcion)
{
    if (!$usuario_id || empty($accion)) return;

    $sql = "INSERT INTO historial_acciones (usuario_id, accion, descripcion) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $usuario_id, $accion, $descripcion);
    $stmt->execute();
    $stmt->close();
}

/**
 * Registrar acción automáticamente usando la sesión del usuario
 * ------------------------------------------------------------
 * Uso en controladores:
 *   registrarHistorialAuto($conn, 'editar', "Editó el documento con ID {$id}.");
 */
function registrarHistorialAuto($conn, $accion, $descripcion)
{
    if (!isset($_SESSION["usuario"]) || empty($accion)) return;

    $usuario = $_SESSION["usuario"];

    // Buscar ID del usuario actual
    $sql = "SELECT id FROM usuarios WHERE usuario = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();

    if ($row && isset($row["id"])) {
        $usuario_id = $row["id"];
        registrarHistorial($conn, $usuario_id, $accion, $descripcion);
    }
}
