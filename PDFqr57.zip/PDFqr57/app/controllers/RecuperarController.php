<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include_once dirname(__DIR__, 2) . "/config/config.php";
require_once dirname(__DIR__, 2) . "/utils/helpers.php";

// ======================================================
//  LIBRERÍAS PDF
// ======================================================
require_once dirname(__DIR__, 2) . "/lib/FPDF/fpdf.php";
require_once dirname(__DIR__, 2) . "/lib/FPDI/src/autoload.php";
require_once dirname(__DIR__, 2) . "/lib/phpqrcode/qrlib.php";

use setasign\Fpdi\Fpdi;

// ======================================================
//  VALIDAR SESIÓN Y PERMISOS
// ======================================================
if (!isset($_SESSION["usuario"])) {
    header("Location: index.php?url=login");
    exit;
}

$usuario = $_SESSION["usuario"];

// Obtener id del capturista
$sqlUser = "SELECT id FROM usuarios WHERE usuario = ?";
$stmtUser = $conn->prepare($sqlUser);
$stmtUser->bind_param("s", $usuario);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();
$id_capturista = ($row = $resultUser->fetch_assoc()) ? $row["id"] : 0;

// Verificar permiso para recuperar
if (!tienePermiso($conn, $id_capturista, "puede_recuperar")) {
    die("<div style='text-align:center;margin-top:50px;'>
            <h3 style='color:red;'>No tienes permiso para recuperar documentos.</h3>
            <a href='index.php?url=documentos' style='color:#9F2241;'>Regresar</a>
        </div>");
}

// ======================================================
//  VALIDAR ID
// ======================================================
if (empty($_GET["id"])) {
    die("Falta el ID del documento.");
}
$id = $_GET["id"];

// ======================================================
//  REACTIVAR DOCUMENTO
// ======================================================
$sql = "UPDATE documentos SET estado_pdf = 'activo' WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $id);
$stmt->execute();

// ======================================================
//  CONSULTAR DOCUMENTO (estructura normalizada)
// ======================================================
$sqlDoc = "SELECT d.*, 
                  p.tipo_predio, p.colonia, p.direccion, p.contribuyente, p.clave_catastral,
                  p.superficie_terreno, p.superficie_construccion,
                  pa.base_gravable, pa.bimestre, pa.linea_captura,
                  pa.recibo_oficial, pa.recibo_mejoras, pa.costo_certificacion,
                  a.nombre AS subdirector, a.cargo
           FROM documentos d
           LEFT JOIN predios p ON d.id = p.documento_id
           LEFT JOIN pagos pa ON d.id = pa.documento_id
           LEFT JOIN autoridades a ON d.autoridad_id = a.id
           WHERE d.id = ?";
$stmtDoc = $conn->prepare($sqlDoc);
$stmtDoc->bind_param("s", $id);
$stmtDoc->execute();
$result = $stmtDoc->get_result();
$doc = $result->fetch_assoc();

if (!$doc) {
    die("Documento no encontrado o inválido.");
}

// ======================================================
//  LIMPIAR DECIMALES Y CAMPOS VACÍOS
// ======================================================
foreach (["superficie_terreno", "superficie_construccion", "costo_certificacion", "base_gravable"] as $campo) {
    $doc[$campo] = isset($doc[$campo]) ? rtrim(rtrim((string)$doc[$campo], '0'), '.') : '';
}

// ======================================================
//  DEFINIR RUTA DE GUARDADO
// ======================================================
$carpetaValidados = dirname(__DIR__, 2) . "/public/validados/";
if (!is_dir($carpetaValidados)) {
    mkdir($carpetaValidados, 0777, true);
}

$filename = ucfirst($doc["tipo_documento"]) . "_" . $doc["id"] . ".pdf";
$rutaPDF = $carpetaValidados . $filename;

// ======================================================
//  GENERAR QR SEGURO (local o Datafox)
// ======================================================
$urlQR = buildAbsoluteUrl("index.php", [
    "url" => "ver_pdf",
    "id"  => $doc["id"]
]);

$tmpQR = tempnam(sys_get_temp_dir(), 'qr_') . '.png';
QRcode::png($urlQR, $tmpQR, QR_ECLEVEL_M, 6, 2);

// Validar QR
if (!file_exists($tmpQR) || filesize($tmpQR) <= 0) {
    error_log("⚠️ Error generando QR para documento ID: " . $doc["id"]);
}

// ======================================================
//  PLANTILLA SEGÚN TIPO
// ======================================================
$plantilla = dirname(__DIR__, 2) . "/plantillas/no_adeudo.pdf";
if ($doc["tipo_documento"] === "aportacion_mejoras") {
    $plantilla = dirname(__DIR__, 2) . "/plantillas/aportacion_mejoras.pdf";
}

// ======================================================
//  CREAR PDF
// ======================================================
$pdf = new Fpdi();
$pdf->AddPage();
$pdf->setSourceFile($plantilla);
$tplIdx = $pdf->importPage(1);
$pdf->useTemplate($tplIdx, 0, 0, 210);
$pdf->SetFont("Arial", "", 12);
$pdf->SetTextColor(0, 0, 0);

// ======================================================
//  FECHA ORIGINAL DE CAPTURA
// ======================================================
$fechaCaptura = new DateTime($doc["fecha_captura"]);
$dia  = $fechaCaptura->format("d");
$anio = $fechaCaptura->format("Y");
$meses = [
    "01" => "ENERO", "02" => "FEBRERO", "03" => "MARZO",
    "04" => "ABRIL", "05" => "MAYO", "06" => "JUNIO",
    "07" => "JULIO", "08" => "AGOSTO", "09" => "SEPTIEMBRE",
    "10" => "OCTUBRE", "11" => "NOVIEMBRE", "12" => "DICIEMBRE"
];
$mes = $meses[$fechaCaptura->format("m")];

// ======================================================
//  BLOQUE: NO ADEUDO
// ======================================================
if ($doc["tipo_documento"] === "no_adeudo") {
    $pdf->SetXY(40, 144);
    $pdf->Cell(120, 10, utf8_decode($doc["contribuyente"]), 0, 0);
    $pdf->SetFont("Arial", "B", 14);
    $pdf->SetTextColor(255, 0, 0);
    $pdf->SetXY(165, 50.5);
    $pdf->Cell(40, 10, " " . $doc["folio_no_adeudo"], 0, 0);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFont("Arial", "", 12);
    $pdf->SetXY(150, 160.5);
    $pdf->Cell(30, 8, $doc["anio_fiscal"], 0, 0);
    $pdf->SetXY(40, 89);
    $pdf->Cell(30, 8, $doc["anio_fiscal"], 0, 0);
    $pdf->SetXY(65, 150);
    $pdf->Cell(60, 8, $doc["clave_catastral"], 0, 0);
    $pdf->SetFont('Arial', '', 8);
    $pdf->SetXY(18, 141.5);
    $pdf->MultiCell(150, 6, utf8_decode(($doc["direccion"] ?? "") . " " . ($doc["colonia"] ?? "")), 0, 'L');
    $pdf->SetFont("Arial", "", 9);
    $pdf->SetXY(18, 160.5);
    $pdf->Cell(40, 8, $doc["base_gravable"], 0, 0);
    $pdf->SetXY(95, 160.5);
    $pdf->Cell(40, 8, $doc["bimestre"], 0, 0);
    $pdf->SetXY(40, 165);
    $pdf->Cell(50, 8, $doc["linea_captura"], 0, 0);
    $pdf->SetXY(40, 170);
    $pdf->Cell(40, 8, utf8_decode($doc["superficie_terreno"] . " MTS"), 0, 0);
    $pdf->SetXY(150, 170);
    $pdf->Cell(40, 8, utf8_decode($doc["superficie_construccion"] . " MTS"), 0, 0);
    $pdf->SetXY(10, 180);
    $pdf->Cell(50, 8, utf8_decode("HAIX " . $doc["recibo_oficial"]), 0, 0);
    $pdf->SetXY(143, 180);
    $pdf->Cell(50, 8, $doc["costo_certificacion"], 0, 0);
    $pdf->SetXY(40, 68.5);
    $pdf->Cell(60, 8, utf8_decode($doc["subdirector"]), 0, 0);
    $pdf->SetXY(40, 74);
    $pdf->Cell(60, 8, utf8_decode($doc["cargo"]), 0, 0);
    $pdf->SetXY(120, 165);
    $pdf->Cell(60, 8, date('d/m/Y', strtotime($doc["fecha_expedicion_pago"])), 0, 0);
    $pdf->SetXY(67, 213);
    $pdf->Cell(15, 8, $dia, 0, 0);
    $pdf->SetXY(117, 213);
    $pdf->Cell(40, 8, $mes, 0, 0);
    $pdf->SetXY(150, 213);
    $pdf->Cell(20, 8, $anio, 0, 0);
}

// ======================================================
//  BLOQUE: APORTACIÓN A MEJORAS
// ======================================================
if ($doc["tipo_documento"] === "aportacion_mejoras") {
    $pdf->SetFont("Arial", "", 12);
    $pdf->SetXY(45, 139.5);
    $pdf->Cell(120, 10, utf8_decode($doc["contribuyente"]), 0, 0);
    $pdf->SetFont("Arial", "B", 14);
    $pdf->SetTextColor(255, 0, 0);
    $pdf->SetXY(166, 50.5);
    $pdf->Cell(40, 10, " " . $doc["folio_aportacion"], 0, 0);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetXY(35, 89.5);
    $pdf->Cell(30, 8, $doc["anio_fiscal"], 0, 0);
    $pdf->SetXY(128, 135.5);
    $pdf->Cell(80, 8, $doc["clave_catastral"], 0, 0);
    $pdf->SetFont('Arial', '', 8);
    $pdf->SetXY(82, 131.5);
    $pdf->MultiCell(150, 6, utf8_decode(($doc["direccion"] ?? "") . " " . ($doc["colonia"] ?? "")), 0, 'L');
    $pdf->SetFont("Arial", "", 12);
    $pdf->SetXY(25, 188.5);
    $pdf->Cell(50, 8, utf8_decode("HAIX " . $doc["recibo_oficial"]), 0, 0);
    $pdf->SetXY(25, 194);
    $pdf->Cell(40, 8, $doc["costo_certificacion"], 0, 0);
    $pdf->SetXY(35, 69.5);
    $pdf->Cell(60, 8, utf8_decode($doc["subdirector"]), 0, 0);
    $pdf->SetXY(35, 74.5);
    $pdf->Cell(60, 8, utf8_decode($doc["cargo"]), 0, 0);
    $pdf->SetXY(68, 213);
    $pdf->Cell(15, 8, $dia, 0, 0);
    $pdf->SetXY(119, 213.5);
    $pdf->Cell(40, 8, $mes, 0, 0);
    $pdf->SetXY(150, 213.5);
    $pdf->Cell(20, 8, $anio, 0, 0);
}

// ======================================================
//  INSERTAR QR Y GUARDAR PDF
// ======================================================
if (file_exists($tmpQR)) {
    $pdf->Image($tmpQR, 170, 225, 28, 28);
    unlink($tmpQR);
}

$pdf->Output("F", $rutaPDF);

registrarHistorialAuto($conn, 'Recuperar', "El usuario {$usuario} recuperó el documento con ID {$id}.");

// ======================================================
//  REDIRECCIÓN CON MENSAJE
// ======================================================
$_SESSION["msg"] = "Documento recuperado correctamente.";
header("Location: index.php?url=documentos");
exit;
