
<!-- AQUI SE ACTUALIZAN LOS PERMISOS DEL PANEL DE ADMINISTRADOR (GESTION DE CAPTURISTAS)-->

<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    include_once dirname(__DIR__, 2) . "/config/config.php";

    $usuario_id = intval($_POST["usuario_id"] ?? 0);
    $permiso = $_POST["permiso"] ?? "";
    $valor = intval($_POST["valor"] ?? 0);

    // Validar datos de entrada
    if ($usuario_id <= 0 || $permiso === "") {
        http_response_code(400);
        echo "Datos inválidos.";
        exit;
    }

    // Validar nombre de columna permitido
    $columnas_permitidas = [
        "puede_ver", "puede_descargar", "puede_editar", "puede_cancelar",
        "puede_recuperar", "puede_entregar", "puede_revocar_entrega"
    ];

    if (!in_array($permiso, $columnas_permitidas)) {
        http_response_code(400);
        echo "Permiso no válido.";
        exit;
    }

    // Actualizar o insertar (solo una fila por usuario)
    $sql = "INSERT INTO permisos_usuarios (usuario_id, $permiso)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE $permiso = VALUES($permiso)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $usuario_id, $valor);

    if ($stmt->execute()) {
        echo "Permiso actualizado correctamente.";
    } else {
        echo "Error al actualizar el permiso: " . $conn->error;
    }
}
?>
