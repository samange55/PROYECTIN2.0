<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}
include_once dirname(__DIR__, 2) . "/config/config.php";

// ======================================================
//  VALIDACIÓN DE ACCESO (ahora usa rol_id)
// ======================================================
if (!isset($_SESSION["usuario"]) || $_SESSION["rol_id"] != 1) {
  header("Location: index.php?url=login");
  exit;
}

// ======================================================
//  TOTALES DE DOCUMENTOS
// ======================================================
$totalDocumentos      = $conn->query("SELECT COUNT(*) AS total FROM documentos")->fetch_assoc()["total"];
$documentosActivos    = $conn->query("SELECT COUNT(*) AS total FROM documentos WHERE estado_pdf='activo'")->fetch_assoc()["total"];
$documentosCancelados = $conn->query("SELECT COUNT(*) AS total FROM documentos WHERE estado_pdf='cancelado'")->fetch_assoc()["total"];
$documentosEntregados = $conn->query("SELECT COUNT(*) AS total FROM documentos WHERE estado_entrega='entregado'")->fetch_assoc()["total"];
$documentosPendientes = $conn->query("SELECT COUNT(*) AS total FROM documentos WHERE estado_entrega='pendiente'")->fetch_assoc()["total"];

// ======================================================
//  USUARIOS Y PERMISOS
// ======================================================
$sql = "SELECT 
            u.id, 
            u.nombre, 
            r.nombre AS rol, 
            u.estado,
            COALESCE(p.puede_ver, 0) AS puede_ver,
            COALESCE(p.puede_descargar, 0) AS puede_descargar,
            COALESCE(p.puede_editar, 0) AS puede_editar,
            COALESCE(p.puede_cancelar, 0) AS puede_cancelar,
            COALESCE(p.puede_recuperar, 0) AS puede_recuperar,
            COALESCE(p.puede_entregar, 0) AS puede_entregar,
            COALESCE(p.puede_revocar_entrega, 0) AS puede_revocar_entrega
        FROM usuarios u
        LEFT JOIN roles r ON u.rol_id = r.id
        LEFT JOIN permisos_usuarios p ON u.id = p.usuario_id
        WHERE r.nombre != 'admin'
        ORDER BY r.nombre ASC, u.nombre ASC";
$usuarios = $conn->query($sql);

// ======================================================
//  HISTORIAL DE MOVIMIENTOS
// ======================================================
$historial = $conn->query("SELECT u.nombre AS usuario, h.accion, h.descripcion, h.fecha 
                           FROM historial_acciones h
                           LEFT JOIN usuarios u ON h.usuario_id = u.id
                           ORDER BY h.fecha DESC LIMIT 15");
?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <!-- Favicon del Panel de Administrador -->
  <link rel="icon" type="image/x-icon" href="public/assets/img/panel_admin2.ico">
  <title>Panel de Administración</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background-color: #f4f4f4;
      font-family: Arial, sans-serif;
    }

    .navbar {
      background-color: #9F2241;
    }

    .navbar-brand,
    .nav-link,
    .navbar-text {
      color: #fff !important;
    }

    .card {
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    }

    .card-header {
      background-color: #9F2241;
      color: white;
      font-weight: bold;
    }

    .table th {
      background-color: #9F2241;
      color: white;
      vertical-align: middle;
    }

    th i {
      margin-right: 6px;
    }

    .nav-link {
      color: #fff !important;
      margin-right: 10px;
      font-weight: 500;
      transition: background-color 0.3s ease;
    }

    .nav-link:hover,
    .nav-link.active {
      background-color: #BC955C;
      color: #fff !important;
      border-radius: 8px;
      padding: 6px 12px;
    }
  </style>
</head>
<script>
  // Marca la pestaña activa según la URL actual
  document.querySelectorAll('.nav-link').forEach(link => {
    if (window.location.href.includes(link.getAttribute('href'))) {
      link.classList.add('active');
    }
  });
</script>

<body>

  <!-- ====================================================== -->
  <!--  BARRA SUPERIOR -->
  <!-- ====================================================== -->
  <nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand" href="index.php?url=admin">
        <i class="bi bi-speedometer2"></i> Panel de Administración
      </a>

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarAdmin" aria-controls="navbarAdmin" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarAdmin">
        <ul class="navbar-nav ms-auto">

          <!-- Pestaña Administración de Usuarios -->
          <li class="nav-item">
            <a href="./index.php?url=admin_usuarios" class="nav-link">
              <i class="bi bi-people-fill"></i> Administración de Usuarios
            </a>
          </li>

          <!-- (Opcional) Pestaña Documentos -->
          <li class="nav-item">
            <a href="./index.php?url=documentos" class="nav-link">
              <i class="bi bi-file-earmark-text"></i> Documentos
            </a>
          </li>

          <!-- Botón de cierre de sesión -->
          <li class="nav-item">
            <a href="./index.php?url=logout" class="nav-link text-danger">
              <i class="bi bi-box-arrow-right"></i> Cerrar sesión
            </a>
          </li>

        </ul>
      </div>
    </div>
  </nav>


  <div class="container my-4">
    <div class="container mt-4">
    <h3 class="ms-4">Administre aquí los permisos de los usuarios</h3>
      </div>

    <!-- ====================================================== -->
    <!--  TARJETAS DE CONTEO -->
    <!-- ====================================================== -->
    <div class="row text-center mb-4">
      <div class="col-md-2">
        <div class="card">
          <div class="card-body">
            <h6>Total Documentos</h6>
            <h2><?= $totalDocumentos ?></h2>
          </div>
        </div>
      </div>
      <div class="col-md-2">
        <div class="card">
          <div class="card-body">
            <h6>Activos</h6>
            <h2><?= $documentosActivos ?></h2>
          </div>
        </div>
      </div>
      <div class="col-md-2">
        <div class="card">
          <div class="card-body">
            <h6>Cancelados</h6>
            <h2><?= $documentosCancelados ?></h2>
          </div>
        </div>
      </div>
      <div class="col-md-2">
        <div class="card">
          <div class="card-body">
            <h6>Entregados</h6>
            <h2><?= $documentosEntregados ?></h2>
          </div>
        </div>
      </div>
      <div class="col-md-2">
        <div class="card">
          <div class="card-body">
            <h6>Pendientes</h6>
            <h2><?= $documentosPendientes ?></h2>
          </div>
        </div>
      </div>
    </div>

    <!-- ====================================================== -->
    <!--  GESTIÓN DE CAPTURISTAS -->
    <!-- ====================================================== -->
    <div class="card mb-4">
      <div class="card-header">Gestión de Capturistas</div>
      <div class="card-body">
        <table class="table table-striped text-center align-middle">
          <thead>
            <tr>
              <th><i class="bi bi-person"></i> Nombre</th>
              <th><i class="bi bi-person-badge"></i> Rol</th>
              <th><i class="bi bi-activity"></i> Estado</th>
              <th><i class="bi bi-eye"></i> Ver</th>
              <th><i class="bi bi-download"></i> Descargar</th>
              <th><i class="bi bi-pencil-square"></i> Editar</th>
              <th><i class="bi bi-x-circle"></i> Cancelar</th>
              <th><i class="bi bi-arrow-counterclockwise"></i> Recuperar Cancelado</th>
              <th><i class="bi bi-box-arrow-down"></i> Entregar</th>
              <th><i class="bi bi-arrow-up-circle"></i> Revocar Entrega</th>
            </tr>
          </thead>
          <tbody>
            <?php while ($u = $usuarios->fetch_assoc()): ?>
              <tr>
                <td><?= htmlspecialchars($u['nombre']) ?></td>
                <td><?= ucfirst($u['rol']) ?></td>
                <td>
                  <span class="badge bg-<?= $u['estado'] == 'activo' ? 'success' : ($u['estado'] == 'afk' ? 'warning' : 'secondary') ?>">
                    <?= strtoupper($u['estado']) ?>
                  </span>
                </td>
                <td><input type="checkbox" data-usuario="<?= $u['id'] ?>" data-permiso="puede_ver" <?= $u['puede_ver'] ? 'checked' : '' ?>></td>
                <td><input type="checkbox" data-usuario="<?= $u['id'] ?>" data-permiso="puede_descargar" <?= $u['puede_descargar'] ? 'checked' : '' ?>></td>
                <td><input type="checkbox" data-usuario="<?= $u['id'] ?>" data-permiso="puede_editar" <?= $u['puede_editar'] ? 'checked' : '' ?>></td>
                <td><input type="checkbox" data-usuario="<?= $u['id'] ?>" data-permiso="puede_cancelar" <?= $u['puede_cancelar'] ? 'checked' : '' ?>></td>
                <td><input type="checkbox" data-usuario="<?= $u['id'] ?>" data-permiso="puede_recuperar" <?= $u['puede_recuperar'] ? 'checked' : '' ?>></td>
                <td><input type="checkbox" data-usuario="<?= $u['id'] ?>" data-permiso="puede_entregar" <?= $u['puede_entregar'] ? 'checked' : '' ?>></td>
                <td><input type="checkbox" data-usuario="<?= $u['id'] ?>" data-permiso="puede_revocar_entrega" <?= $u['puede_revocar_entrega'] ? 'checked' : '' ?>></td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- ====================================================== -->
    <!--  HISTORIAL DE MOVIMIENTOS -->
    <!-- ====================================================== -->
    <div class="card">
      <div class="card-header">Historial de Movimientos Recientes</div>
      <div class="card-body">
        <table class="table table-hover">
          <thead>
            <tr>
              <th>Usuario</th>
              <th>Acción</th>
              <th>Descripción</th>
              <th>Fecha</th>
            </tr>
          </thead>
          <tbody>
            <?php while ($h = $historial->fetch_assoc()): ?>
              <tr>
                <td><?= htmlspecialchars($h['usuario']) ?></td>
                <td><?= htmlspecialchars($h['accion']) ?></td>
                <td><?= htmlspecialchars($h['descripcion']) ?></td>
                <td><?= $h['fecha'] ?></td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- ====================================================== -->
  <!--  SCRIPT PARA ACTUALIZAR PERMISOS -->
  <!-- ====================================================== -->
  <script>
    document.querySelectorAll('input[type="checkbox"]').forEach(chk => {
      chk.addEventListener('change', function() {
        const usuario_id = this.getAttribute('data-usuario');
        const permiso = this.getAttribute('data-permiso');
        const valor = this.checked ? 1 : 0;

        fetch('app/controllers/ActualizarPermiso.php', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `usuario_id=${usuario_id}&permiso=${permiso}&valor=${valor}`
          })
          .then(res => res.text())
          .then(data => console.log(data))
          .catch(err => console.error('Error:', err));
      });
    });
  </script>

</body>

</html>