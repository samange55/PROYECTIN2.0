<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include_once dirname(__DIR__, 2) . "/config/config.php";

// ==========================
//  Verificar sesión
// ==========================
if (!isset($_SESSION["usuario"])) {
    header("Location: index.php?url=login");
    exit;
}

// ==========================
//  Solo aceptar POST
// ==========================
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php?url=documentos");
    exit;
}

// ==========================
//  Validar ID recibido
// ==========================
if (empty($_POST["id"])) {
    $_SESSION["msg_error"] = "ID inválido (no recibido).";
    header("Location: index.php?url=documentos");
    exit;
}

$id = trim($_POST["id"]);

include_once dirname(__DIR__, 2) . "/utils/helpers.php";

// ==========================
//  Obtener ID del usuario actual
// ==========================
$usuario = $_SESSION["usuario"];
$sqlUser = "SELECT id FROM usuarios WHERE usuario = ?";
$stmtUser = $conn->prepare($sqlUser);
$stmtUser->bind_param("s", $usuario);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();
$id_capturista = ($row = $resultUser->fetch_assoc()) ? $row["id"] : 0;

// ==========================
//  Validar permiso de entrega
// ==========================
if (!tienePermiso($conn, $id_capturista, "puede_entregar")) {
    die("<div style='text-align:center;margin-top:50px;'>
            <h3 style='color:red;'> No tienes permiso para marcar documentos como ENTREGADOS.</h3>
            <a href='index.php?url=documentos' style='color:#9F2241;'>Regresar</a>
        </div>");
}


// ==========================
//  Actualizar estado de entrega
// ==========================
$sql = "UPDATE documentos SET estado_entrega = 'entregado' WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $id);

if ($stmt->execute()) {
    $_SESSION["msg_success"] = " Documento marcado como ENTREGADO correctamente.";
} else {
    $_SESSION["msg_error"] = "Error al actualizar el estado de entrega: " . $conn->error;
}

// --- Registrar movimiento ---
registrarHistorialAuto($conn, 'Entregar', "El usuario {$_SESSION['usuario']} entregó el documento con ID {$id}.");


// ==========================
//  Redirigir de vuelta a documentos
// ==========================
header("Location: index.php?url=documentos");
exit;
