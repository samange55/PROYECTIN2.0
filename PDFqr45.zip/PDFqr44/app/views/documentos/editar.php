<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once dirname(__DIR__, 3) . "/config/config.php";

// Verificar usuario
if (!isset($_SESSION["usuario"])) {
    header("Location: index.php?url=login");
    exit;
}

$usuario = $_SESSION["usuario"];

// Obtener id_capturista
$sqlUser = "SELECT id FROM QRusuarios WHERE usuario = ?";
$stmtUser = $conn->prepare($sqlUser);
$stmtUser->bind_param("s", $usuario);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();
$id_capturista = ($row = $resultUser->fetch_assoc()) ? $row["id"] : 0;

// Verificar si recibimos el id del documento
if (!isset($_GET["id"])) {
    die("ID de documento no proporcionado.");
}
$id_doc = $_GET["id"];

// Obtener datos del documento
$sql = "SELECT * FROM QRdocumentos WHERE id = ? AND id_capturista = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $id_doc, $id_capturista);
$stmt->execute();
$result = $stmt->get_result();
$doc = $result->fetch_assoc();

if (!$doc) {
    die("Documento no encontrado o no tienes permisos para editarlo.");
}

// Si envía el formulario para actualizar
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["actualizar_doc"])) {
    $fecha_captura = $_POST["fecha_captura"];
    $anio_fiscal = $_POST["anio_fiscal"];
    $tipo_documento = $_POST["tipo_documento"];
    $folio_no_adeudo = $_POST["folio_no_adeudo"];
    $folio_aportacion = $_POST["folio_aportacion"];
    $linea_captura = $_POST["linea_captura"];
    $tipo_predio = $_POST["tipo_predio"];

    // Manejo de colonia y colonia_otro
    $colonia = $_POST["colonia"];
    $colonia_otro = isset($_POST["colonia_otro"]) ? $_POST["colonia_otro"] : null;
    if ($colonia === "Otro" && !empty($colonia_otro)) {
        $colonia = $colonia_otro;
    }

    $direccion = $_POST["direccion"];
    $contribuyente = $_POST["contribuyente"];
    $clave_catastral = $_POST["clave_catastral"];
    $base_gravable = $_POST["base_gravable"];
    $bimestre = $_POST["bimestre"];
    $superficie_terreno = $_POST["superficie_terreno"];
    $superficie_construccion = $_POST["superficie_construccion"];
    $subdirector = $_POST["subdirector"];
    $cargo = $_POST["cargo"];
    $recibo_oficial = $_POST["recibo_oficial"];
    $recibo_mejoras = $_POST["recibo_mejoras"];
    $costo_certificacion = $_POST["costo_certificacion"];

    $sqlUpdate = "UPDATE QRdocumentos 
                  SET fecha_captura=?, anio_fiscal=?, tipo_documento=?, 
                      folio_no_adeudo=?, folio_aportacion=?, linea_captura=?, 
                      tipo_predio=?, colonia=?, direccion=?, clave_catastral=?, 
                      base_gravable=?, bimestre=?, 
                      superficie_terreno=?, superficie_construccion=?, 
                      contribuyente=?, subdirector=?, cargo=?, 
                      recibo_oficial=?, recibo_mejoras=?, costo_certificacion=? 
                  WHERE id = ? AND id_capturista = ?";
    $stmtUpdate = $conn->prepare($sqlUpdate);
    $stmtUpdate->bind_param(
    "sissssssssdiddsssssdsi",
    
    $fecha_captura, $anio_fiscal, $tipo_documento,
    $folio_no_adeudo, $folio_aportacion, $linea_captura,
    $tipo_predio, $colonia, $direccion, $clave_catastral,
    $base_gravable, $bimestre, $superficie_terreno, $superficie_construccion,
    $contribuyente, $subdirector, $cargo,
    $recibo_oficial, $recibo_mejoras, $costo_certificacion,
    $id_doc, $id_capturista
);


  if ($stmtUpdate->execute()) {
        // --- Borrar PDF viejo si existe ---
        $filename = ucfirst($tipo_documento) . "_" . $id_doc . ".pdf";
        $savePath = dirname(__DIR__, 3) . "/public/validados/" . $filename;

        if (file_exists($savePath)) {
            unlink($savePath); // Elimina el PDF viejo
        }

        $_SESSION["msg"] = "Documento actualizado correctamente.";
        header("Location: index.php?url=documentos");
        exit;
    } else {
        $error = "Error al actualizar: " . $conn->error;
    }
}

?>

<?php include dirname(__DIR__) . "/layout/header.php"; ?>

<div class="row justify-content-center">
  <div class="col-lg-10">
    <div class="card p-4 mb-4">
      <h4 class="text-center">Editar Documento</h4>
      <?php if (isset($error)) { ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
      <?php } ?>

      <form method="post" class="row g-3">
        <!-- Datos del documento -->
        <h5 class="mt-3">Datos del documento</h5>
        <div class="col-md-4">
          <label class="form-label">Fecha de captura</label>
          <input type="date" name="fecha_captura" value="<?php echo $doc['fecha_captura']; ?>" class="form-control" required>
        </div>
        <div class="col-md-4">
          <label class="form-label">Año fiscal</label>
          <input type="number" name="anio_fiscal" value="<?php echo $doc['anio_fiscal']; ?>" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Tipo de documento</label>
          <select name="tipo_documento" class="form-select">
            <option value="no_adeudo" <?php if($doc['tipo_documento']=='no_adeudo') echo 'selected'; ?>>No adeudo predial</option>
            <option value="aportacion_mejoras" <?php if($doc['tipo_documento']=='aportacion_mejoras') echo 'selected'; ?>>Aportación a mejoras</option>
          </select>
        </div>

        <!-- Identificación y folios -->
        <h5 class="mt-3">Identificación y folios</h5>
        <div class="col-md-4">
          <label class="form-label">Folio No adeudo predial</label>
          <input type="text" name="folio_no_adeudo" value="<?php echo $doc['folio_no_adeudo']; ?>" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Folio Aportación</label>
          <input type="text" name="folio_aportacion" value="<?php echo $doc['folio_aportacion']; ?>" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Línea de captura</label>
          <input type="text" name="linea_captura" value="<?php echo $doc['linea_captura']; ?>" class="form-control">
        </div>

        <!-- Datos del predio -->
        <h5 class="mt-3">Datos del predio</h5>
        <div class="col-md-4">
          <label class="form-label">Tipo de predio</label>
          <select name="tipo_predio" class="form-select">
            <option value="Construido" <?php if($doc['tipo_predio']=='Construido') echo 'selected'; ?>>Construido</option>
            <option value="Sin construir" <?php if($doc['tipo_predio']=='Sin construir') echo 'selected'; ?>>Sin construir</option>
            <option value="Baldío" <?php if($doc['tipo_predio']=='Baldío') echo 'selected'; ?>>Baldío</option>
            <option value="Otro" <?php if($doc['tipo_predio']=='Otro') echo 'selected'; ?>>Otro</option>
          </select>
        </div>

        <!-- Colonia -->
        <div class="col-md-4">
          <label class="form-label">Colonia</label>
          <select name="colonia" id="colonia" class="form-select" onchange="toggleOtraColonia()">
            <option value="">Seleccione una colonia</option>
            <?php
            $colonias = [ '18 de Agosto','1ro de Mayo','20 de Noviembre','6 de Junio','Alfredo del Mazo',
            'Ampliación 6 de Junio','Ampliación Acozac','Ampliación Dr. Jorge Jiménez Cantú','Ampliación Escalerillas',
            'Ampliación Loma Bonita','Ampliación Luis Córdova Reyes','Ampliación Morelos',
            'Ampliación Plutarco Elías Calles','Ampliación San Francisco','Ampliación Santo Tomás',
            'Ampliación Tejalpa','Aquiles Córdoba Morán','Ávila Camacho','Ayotla Centro','Azizintla','Benito Quezada',
            'Capillas I','Capillas II','Capillas III y IV','Cerro de Moctezuma','Citlalmina','Ciudad Cuatro Vientos',
            'Clara Córdova Morán','Coatepec','Contadero','Cumbres de la Montaña','Derramadero','Dr. Jorge Jiménez Cantú',
            'El Cacerio','El Capulín','El Caracol','El Carmen','El Chililico','El Gato','El Magueyal','El Magisterio',
            'El Mirador','El Mirto','El Molino','El Ocote','El Panteón','El Patronato','El Pilar','El Pino','El Tablón',
            'El Tejolote','Elsa Córdova Morán','Emiliano Zapata','Escalerillas','Espartaco','Estado de México','F. Álvarez',
            'Fracc. Izcalli Ixtapaluca','Fracc. Jose de la Mora','Fracc. Rancho El Carmen',
            'Fraccionamiento Unidad Deportiva Residencial Acozac','Fraternidad','Geovillas de Jesús María',
            'Geovillas de San Jacinto','Geovillas de Santa Bárbara','Geovillas Ixtapaluca 2000','Gonzalo López Cid',
            'Hornos de San Francisco','Hornos de Santa Bárbara','Hornos de Zoquiapan','Humberto Gutiérrez',
            'Humberto Vidal Mendoza','Ilhuilcamina','Independencia','Ixtapaluca Centro','Jacarandas','Jesús María',
            'José Guadalupe Posada (UPREZ)','Juan Antonio Soberanes','La Antorcha','La cañada','La Guadalupana','La Huerta',
            'La Magdalena Atlipac','La Presa','La Retama','La Venta','La Virgen','Las Palmas 2da Sección',
            'Las Palmas 3ra Etapa','Las Palmas Hacienda','Lavaderos','Lindavista','Llano Grande','Loma Bonita',
            'Loma del Rayo','Lomas de Ayotla','Lomas de Coatepec','Lomas de Ixtapaluca','Los Depósitos','Los Héroes',
            'Los Héroes Tezontle','Luis Córdova Reyes','Luis Donaldo Colosio','Manuel Serrano Vallejo',
            'Marco Antonio Sosa Balderas','Margarita Moran','Melchor Ocampo','Morelos (Nueva Independencia)',
            'Nueva Antorcha','Nueva Antorchista','Nuevo Jardín Industrial Ixtapaluca','Paseos de Coatepec',
            'Peña de la Rosa de Castilla','Piedras Grandes','Plutarco Elías Calles','Pueblo Nuevo','Rancho Guadalupe',
            'Rancho San José','Rancho Verde','Real del Campo','Residencial Ayotla','Residential Park','Rey Izcoatl',
            'Rey Izcoatl 2da Sección','Rey Izcoatl 3ra Sección','Ricardo Calva','Rigoberta Menchú','Rincón del Bosque',
            'Río Frío','Rosa de San Francisco','San Antonio Tlalpizahuac.','San Buenaventura','San Francisco Acuautla',
            'San Isidro','San Jerónimo','San José de la Palma','San Juan','San Juan San Antonio',
            'San Juan Tlalpizac.','San Miguel','Santa Bárbara','Santa Cruz Tlalpizac','Santa Cruz Tlapacoya',
            'Santo Tomás','Tecomatlan','Tejalpa','Teponaxtle','Tetitla','Tezontle','Tlacaelel','Tlapacoya Pueblo',
            'Tlayehuale','Unidad Magisterial','Valle Verde','Victorio Soto Wenceslao','Villas de Antorcha',
            'Villas de Ayotla','Volcanes','Wenceslao','Xochitenco','Zona Industrial Ayotla','Zoquiapan','Otro' ];
            foreach ($colonias as $c) {
                $selected = ($doc['colonia'] == $c) ? "selected" : "";
                echo "<option value='$c' $selected>$c</option>";
            }
            ?>
          </select>
        </div>

        <!-- Campo para otra colonia -->
        <div class="col-md-4" id="colonia_otro_div" style="<?php echo ($doc['colonia']=='Otro' ? '' : 'display:none;'); ?>">
          <label class="form-label">Especifique otra colonia</label>
          <input type="text" name="colonia_otro" id="colonia_otro" value="<?php echo $doc['colonia']; ?>" class="form-control">
        </div>

        <div class="col-md-4">
          <label class="form-label">Dirección</label>
          <input type="text" name="direccion" value="<?php echo $doc['direccion']; ?>" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Clave catastral</label>
          <input type="text" name="clave_catastral" value="<?php echo $doc['clave_catastral']; ?>" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Base gravable</label>
          <input type="number" step="0.01" name="base_gravable" value="<?php echo $doc['base_gravable']; ?>" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Bimestre</label>
          <select name="bimestre" class="form-select">
            <?php for ($i=1; $i<=6; $i++): ?>
              <option value="<?= $i ?>" <?php if($doc['bimestre']==$i) echo 'selected'; ?>><?= $i ?></option>
            <?php endfor; ?>
          </select>
        </div>
        <div class="col-md-4">
          <label class="form-label">Superficie terreno </label>
          <input type="number" step="0.01" name="superficie_terreno" value="<?php echo $doc['superficie_terreno']; ?>" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Superficie construcción </label>
          <input type="number" step="0.01" name="superficie_construccion" value="<?php echo $doc['superficie_construccion']; ?>" class="form-control">
        </div>

        <!-- Contribuyente y validación -->
        <h5 class="mt-3">Contribuyente y validación</h5>
        <div class="col-md-4">
          <label class="form-label">Nombre del contribuyente</label>
          <input type="text" name="contribuyente" value="<?php echo $doc['contribuyente']; ?>" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Subdirector</label>
          <input type="text" name="subdirector" value="<?php echo $doc['subdirector']; ?>" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Cargo</label>
          <input type="text" name="cargo" value="<?php echo $doc['cargo']; ?>" class="form-control">
        </div>

        <!-- Recibos y certificación -->
        <h5 class="mt-3">Recibos y certificación</h5>
        <div class="col-md-4">
          <label class="form-label">Recibo oficial</label>
          <input type="text" name="recibo_oficial" value="<?php echo $doc['recibo_oficial']; ?>" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Recibo mejoras</label>
          <input type="text" name="recibo_mejoras" value="<?php echo $doc['recibo_mejoras']; ?>" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Costo de certificación</label>
          <input type="number" step="0.01" name="costo_certificacion" value="<?php echo $doc['costo_certificacion']; ?>" class="form-control">
        </div>

        <div class="col-12 mt-3">
          <button type="submit" name="actualizar_doc" class="btn btn-primary w-100">Actualizar documento</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function toggleOtraColonia() {
    const select = document.getElementById("colonia");
    const otroDiv = document.getElementById("colonia_otro_div");
    if (select.value === "Otro") {
        otroDiv.style.display = "block";
    } else {
        otroDiv.style.display = "none";
        document.getElementById("colonia_otro").value = "";
    }
}
</script>
