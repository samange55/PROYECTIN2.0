<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "config.php";

// Verificar usuario
if (!isset($_SESSION["usuario"])) {
    header("Location: login.php");
    exit;
}

$usuario = $_SESSION["usuario"];
$sqlUser = "SELECT id FROM QRusuarios WHERE usuario = ?";
$stmtUser = $conn->prepare($sqlUser);
$stmtUser->bind_param("s", $usuario);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();
$id_capturista = ($row = $resultUser->fetch_assoc()) ? $row["id"] : 0;

// 🔹 Corregido: traer todas las columnas necesarias, no solo 4
$sqlDocs = "SELECT id, fecha_captura, contribuyente, folio_no_adeudo, folio_aportacion, clave_catastral, tipo_documento 
            FROM QRdocumentos 
            WHERE id_capturista = ? 
            ORDER BY fecha_captura DESC";
$stmtDocs = $conn->prepare($sqlDocs);
$stmtDocs->bind_param("i", $id_capturista);
$stmtDocs->execute();
$docs = $stmtDocs->get_result();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Documentos Capturados</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f4f4;
        }
        .navbar {
            background-color: #9F2241;
        }
        .navbar-brand, .nav-link, .navbar-text {
            color: #fff !important;
        }
        .btn-docs, .btn-logout, .btn-new {
            background: none;
            border: none;
            color: #fff;
            font-size: 1rem;
            cursor: pointer;
            padding: 0;
            transition: color 0.3s ease;
            text-decoration: none; /*  evita subrayado */
        }
        .btn-docs:hover, .btn-logout:hover, .btn-new:hover {
            color: #ffd700;
            text-decoration: none;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
      <img src="IXTALOGO.png" alt="Logo" height="40" class="me-2"> Sistema de Validación de Documentos
    </a>
    <ul class="navbar-nav ms-auto d-flex align-items-center">
        <li class="nav-item me-3"></li>
        <li class="nav-item me-3">
            <a href="dashboard.php" class="btn-new">Nuevo Documento</a>
        </li>
        <li class="nav-item me-3">
            <a href="documentos.php" class="btn-docs">Documentos capturados</a>
        </li>
        <li class="nav-item">
            <a href="logout.php" class="btn-logout">Cerrar sesión</a>
        </li>
    </ul>
  </div>
</nav>

<div class="container mt-4">
    <h3 class="mb-3">Documentos Capturados</h3>
    <div class="table-responsive">
        <table class="table table-striped align-middle">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Fecha</th>
                    <th>Contribuyente</th>
                    <th>Folio No adeudo</th>
                    <th>Folio Aportación</th>
                    <th>Clave catastral</th>
                    <th>Tipo documento</th>
                    <th>Acciones</th> <!-- Nueva columna -->
                </tr>
            </thead>
            <tbody>
                <?php if ($docs->num_rows > 0) { while ($row = $docs->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row["id"]; ?></td>
                    <td><?php echo $row["fecha_captura"]; ?></td>
                    <td><?php echo $row["contribuyente"]; ?></td>
                    <td><?php echo $row["folio_no_adeudo"]; ?></td>
                    <td><?php echo $row["folio_aportacion"]; ?></td>
                    <td><?php echo $row["clave_catastral"]; ?></td>
                    <td>
                        <span class="badge bg-<?php echo $row["tipo_documento"] == 'no_adeudo' ? 'success' : 'warning'; ?>">
                            <?php echo $row["tipo_documento"]; ?>
                        </span>
                    </td>
                    <td>
                        <!--  Botón Editar -->
                        <a href="editar_archivo.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-primary me-1">Editar</a>
                        
                        <!--  Botón Ver PDF -->
                        <a href="ver_pdf.php?id=<?php echo $row['id']; ?>" target="_blank" class="btn btn-sm btn-info me-1">Ver PDF</a>
                        
                        <!--  Botón Descargar PDF -->
                        <a href="descargar_pdf.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-success me-1">Descargar</a>
                        
                        <!--  Botón Eliminar con confirmación -->
                        <a href="eliminar_documento.php?id=<?php echo $row['id']; ?>" 
                           class="btn btn-sm btn-danger"
                           onclick="return confirm('¿Deseas eliminar este archivo?');">
                           Eliminar
                        </a>
                    </td>
                </tr>
                <?php }} else { ?>
                <tr>
                    <td colspan="8" class="text-center">No hay documentos registrados</td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
