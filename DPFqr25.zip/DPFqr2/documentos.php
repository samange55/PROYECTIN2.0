<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "config.php";

// Verificar usuario
if (!isset($_SESSION["usuario"])) {
    header("Location: login.php");
    exit;
}

$usuario = $_SESSION["usuario"];
$sqlUser = "SELECT id FROM QRusuarios WHERE usuario = ?";
$stmtUser = $conn->prepare($sqlUser);
$stmtUser->bind_param("s", $usuario);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();
$id_capturista = ($row = $resultUser->fetch_assoc()) ? $row["id"] : 0;

$sqlDocs = "SELECT fecha_captura, contribuyente, clave_catastral, tipo_documento 
            FROM QRdocumentos 
            WHERE id_capturista = ? 
            ORDER BY fecha_captura DESC";
$stmtDocs = $conn->prepare($sqlDocs);
$stmtDocs->bind_param("i", $id_capturista);
$stmtDocs->execute();
$docs = $stmtDocs->get_result();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Documentos Capturados</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f4f4;
        }
        .navbar {
            background-color: #9F2241;
        }
        .navbar-brand, .nav-link, .navbar-text {
            color: #fff !important;
        }
        .btn-docs, .btn-logout, .btn-new {
            background: none;
            border: none;
            color: #fff;
            font-size: 1rem;
            cursor: pointer;
            padding: 0;
            transition: color 0.3s ease;
        }
        .btn-docs:hover, .btn-logout:hover,.btn-new:hover {
            color: #ffd700;
            text-decoration: none;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
      <img src="IXTALOGO.png" alt="Logo" height="40" class="me-2"> Sistema de Validación de Documentos
    </a>
    <ul class="navbar-nav ms-auto d-flex align-items-center">
        <li class="nav-item me-3">
            
        </li>
        <li class="nav-item me-3">
            <a href="dashboard.php" class="btn-new">Nuevo Documento</a>
        </li>
        <li class="nav-item me-3">
            <a href="documentos.php" class="btn-docs">Documentos capturados</a>
        </li>
        <li class="nav-item">
            <a href="logout.php" class="btn-logout">Cerrar sesión</a>
        </li>
    </ul>
  </div>
</nav>

<div class="container mt-4">
    <h3 class="mb-3">Mis Documentos Capturados</h3>
    <div class="table-responsive">
        <table class="table table-striped align-middle">
            <thead class="table-dark">
                <tr>
                    <th>Fecha</th>
                    <th>Contribuyente</th>
                    <th>Clave</th>
                    <th>Tipo</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($docs->num_rows > 0) { while ($row = $docs->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row["fecha_captura"]; ?></td>
                    <td><?php echo $row["contribuyente"]; ?></td>
                    <td><?php echo $row["clave_catastral"]; ?></td>
                    <td>
                        <span class="badge bg-<?php echo $row["tipo_documento"] == 'no_adeudo' ? 'success' : 'warning'; ?>">
                            <?php echo $row["tipo_documento"]; ?>
                        </span>
                    </td>
                </tr>
                <?php }} else { ?>
                <tr>
                    <td colspan="4" class="text-center">No hay documentos registrados</td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
