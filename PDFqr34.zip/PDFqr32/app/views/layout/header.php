<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once dirname(__DIR__, 3) . "/config/config.php"; 
require_once dirname(__DIR__, 3) . "/utils/helpers.php"; // 👈 incluye helper

// Obtener documentos del usuario logueado
if (isset($_SESSION["usuario"])) {
    $usuario = $_SESSION["usuario"];
    $sqlUser = "SELECT id FROM QRusuarios WHERE usuario = ?";
    $stmtUser = $conn->prepare($sqlUser);
    $stmtUser->bind_param("s", $usuario);
    $stmtUser->execute();
    $resultUser = $stmtUser->get_result();
    $id_capturista = ($row = $resultUser->fetch_assoc()) ? $row["id"] : 0;

    $sqlDocs = "SELECT fecha_captura, contribuyente, clave_catastral, tipo_documento 
                FROM QRdocumentos 
                WHERE id_capturista = ? 
                ORDER BY fecha_captura DESC";
    $stmtDocs = $conn->prepare($sqlDocs);
    $stmtDocs->bind_param("i", $id_capturista);
    $stmtDocs->execute();
    $docs = $stmtDocs->get_result();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Captura de Documentos</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f4f4;
        }
        .navbar {
            background-color: #9F2241;
        }
        .navbar-brand, .nav-link, .navbar-text {
            color: #fff !important;
        }
        .card {
            border-radius: 12px;
            box-shadow: 0px 2px 6px rgba(15, 18, 15, 0.1);
        }
        .btn-primary {
            background-color: #BC955C;
            border: none;
        }
        .btn-primary:hover {
            background-color: #a58343ff;
        }
        footer {
            background: #003366;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 30px;
        }
        #tablaDocumentos {
            display: none;
            background: #fff;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 8px;
            box-shadow: 0px 4px 6px rgba(0,0,0,0.1);
        }
        .btn-docs, .btn-logout, .btn-new-doc {
            background: none;
            border: none;
            color: #fff;
            font-size: 1rem;
            cursor: pointer;
            padding: 0;
            transition: color 0.3s ease;
        }
        .btn-docs:hover, .btn-logout:hover, .btn-new-doc:hover {
            color: #ffd700;
            text-decoration: none;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand d-flex align-items-center" href="index.php?url=dashboard">
      <img src="<?php echo buildAbsoluteUrl('public/assets/img/IXTALOGO.png'); ?>" alt="Logo" style="height:50px;">
      <span class="ms-2">Sistema de Validación de Documentos</span>
    </a>

    <?php if (isset($_SESSION["usuario"])) { ?>
    <ul class="navbar-nav ms-auto d-flex align-items-center">
        <li class="nav-item me-3">
            <span class="navbar-text"></span>
        </li>
        <li class="nav-item me-3">
            <a href="index.php?url=dashboard" class="btn-new-doc">Nuevo Documento</a>
        </li>
        <li class="nav-item me-3">
          <a href="index.php?url=documentos" class="btn-docs">Documentos capturados</a>
        </li>
        <li class="nav-item">
            <a href="index.php?url=logout" class="btn-logout">Cerrar sesión</a>
        </li>
    </ul>
    <?php } ?>
  </div>
</nav>

<!-- TABLA OCULTA POR DEFECTO -->
<div class="container mt-3" id="tablaDocumentos">
    <h5 class="mb-3">Documentos capturados</h5>
    <div class="table-responsive">
        <table class="table table-striped align-middle">
            <thead class="table-dark">
                <tr>
                    <th>Fecha</th>
                    <th>Contribuyente</th>
                    <th>Clave</th>
                    <th>Tipo</th>
                </tr>
            </thead>
            <tbody>
                <?php if (isset($docs)) { while ($row = $docs->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row["fecha_captura"]; ?></td>
                    <td><?php echo $row["contribuyente"]; ?></td>
                    <td><?php echo $row["clave_catastral"]; ?></td>
                    <td>
                        <span class="badge bg-<?php echo $row["tipo_documento"] == 'no_adeudo' ? 'success' : 'warning'; ?>">
                            <?php echo $row["tipo_documento"]; ?>
                        </span>
                    </td>
                </tr>
                <?php }} ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    const toggle = document.getElementById("toggleTabla");
    const tabla = document.getElementById("tablaDocumentos");

    if (toggle) {
        toggle.addEventListener("click", () => {
            tabla.style.display = tabla.style.display === "none" ? "block" : "none";
            if (tabla.style.display === "block") {
                tabla.scrollIntoView({ behavior: "smooth" });
            }
        });
    }
</script>

<div class="container mt-4">
