<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once dirname(__DIR__, 2) . "/config/config.php";

// Verificar usuario
if (!isset($_SESSION["usuario"])) {
    header("Location: index.php?url=login");
    exit;
}

if (!isset($_GET["id"])) {
    die("ID no especificado.");
}

$id = intval($_GET["id"]);

$sql = "UPDATE QRdocumentos SET estado_entrega = 'entregado' WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    $_SESSION["msg"] = "Documento marcado como ENTREGADO correctamente.";
} else {
    $_SESSION["msg"] = "Error al actualizar el estado de entrega.";
}

header("Location: index.php?url=documentos");
exit;
