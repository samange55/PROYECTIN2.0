<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once dirname(__DIR__, 2) . "/config/config.php";

// Verificar usuario
if (!isset($_SESSION["usuario"])) {
    header("Location: index.php?url=login");
    exit;
}

// Validar ID
$id = $_GET["id"] ?? null;
if (!$id) {
    die("Falta el ID del documento.");
}

// Consultar únicamente el tipo_documento (NO borramos nada en BD)
$stmt = $conn->prepare("SELECT tipo_documento FROM QRdocumentos WHERE id = ?");
$stmt->bind_param("s", $id);
$stmt->execute();
$res = $stmt->get_result();
$doc = $res->fetch_assoc();

if (!$doc) {
    die("Documento no encontrado.");
}

// Armar ruta del PDF validado
$filename = ucfirst($doc["tipo_documento"]) . "_" . $id . ".pdf";
$path = dirname(__DIR__, 2) . "/public/validados/" . $filename;

// Intentar eliminar solo el archivo
if (file_exists($path)) {
    if (@unlink($path)) {
        $msg = "El PDF validado fue eliminado: $filename";
    } else {
        $msg = "No se pudo eliminar el PDF (revisa permisos de carpeta).";
    }
} else {
    $msg = "No existe un PDF validado para este documento ($filename).";
}

// Volver al listado con mensaje
header("Location: index.php?url=documentos&msg=" . urlencode($msg));
exit;
