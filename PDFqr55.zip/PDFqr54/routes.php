<?php
return [

    // Admin
    "admin" => "app/controllers/AdminController.php",
    // Administrador de Usuarios
    "admin_usuarios"   => "app/controllers/AdminUsuariosController.php",


    // Usuarios
    "login"      => "app/views/usuarios/login.php",
    "registro"   => "app/views/usuarios/registro.php",
    "logout"     => "app/views/usuarios/logout.php",

    // Dashboard
    "dashboard"  => "app/views/layout/dashboard.php",

    // Documentos
    "documentos" => "app/controllers/DocumentosController.php",
    "nuevo"      => "app/views/documentos/editar.php",
    "editar"     => "app/views/documentos/editar.php",
    "eliminar"   => "app/views/documentos/eliminar.php",
    "entregar_doc" => "app/controllers/EntregarController.php",
    "revocar_entrega" => "app/controllers/RevocarEntregaController.php",

    // Exportaciones
    "export_csv" => "app/controllers/export/exportar_csv.php",

    // PDFs
    "ver_pdf"    => "app/views/documentos/ver_pdf.php",
    "descargar"  => "app/controllers/DescargarController.php",

    //Cancelar PDFs
    "cancelar" => "app/controllers/CancelarController.php",
    "recuperar" => "app/controllers/RecuperarController.php",

    // ver ambos documentos ADEUDO Y MEJORAS
    "ver_pdf_ambos" => "app/views/documentos/ver_pdf_ambos.php",

];
