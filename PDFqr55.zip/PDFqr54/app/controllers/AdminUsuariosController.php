<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include_once dirname(__DIR__, 2) . "/config/config.php";

// ============================
//  VERIFICAR SESIÓN ADMIN
// ============================
if (!isset($_SESSION["usuario"]) || $_SESSION["rol_id"] != 1) {
    header("Location: index.php?url=login");
    exit;
}


// ======================================================
//  CONSULTAR LISTA DE USUARIOS Y ROLES
// ======================================================
$sql = "SELECT u.*, r.nombre AS rol_nombre 
        FROM usuarios u
        LEFT JOIN roles r ON u.rol_id = r.id
        ORDER BY u.id DESC";
$usuarios = $conn->query($sql);

$roles = $conn->query("SELECT id, nombre FROM roles ORDER BY id ASC");

// ======================================================
//  CREAR NUEVO USUARIO
// ======================================================
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["crear"])) {
    $usuario = trim($_POST["usuario"]);
    $password = trim($_POST["password"]);
    $nombre = trim($_POST["nombre"]);
    $rol_id = intval($_POST["rol_id"]);
    $activo = isset($_POST["activo"]) ? 1 : 0;
    $estado = $_POST["estado"];

    if (empty($usuario) || empty($password) || empty($nombre)) {
        $_SESSION["msg_error"] = "Todos los campos son obligatorios.";
        header("Location: index.php?url=admin_usuarios");
        exit;
    }

    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO usuarios (usuario, password, nombre, rol_id, activo, estado) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssiss", $usuario, $passwordHash, $nombre, $rol_id, $activo, $estado);

    if ($stmt->execute()) {
        $_SESSION["msg_success"] = "Usuario creado correctamente.";
    } else {
        $_SESSION["msg_error"] = "Error al crear el usuario (puede que el nombre de usuario ya exista).";
    }

    header("Location: index.php?url=admin_usuarios");
    exit;
}

// ======================================================
//  EDITAR USUARIO
// ======================================================
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["editar"])) {
    $id = intval($_POST["id"]);
    $nombre = trim($_POST["nombre"]);
    $rol_id = intval($_POST["rol_id"]);
    $estado = $_POST["estado"];
    $activo = isset($_POST["activo"]) ? 1 : 0;
    $nuevaPass = trim($_POST["password"]);

    if (!empty($nuevaPass)) {
        $passwordHash = password_hash($nuevaPass, PASSWORD_DEFAULT);
        $sql = "UPDATE usuarios SET nombre=?, password=?, rol_id=?, estado=?, activo=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssissi", $nombre, $passwordHash, $rol_id, $estado, $activo, $id);
    } else {
        $sql = "UPDATE usuarios SET nombre=?, rol_id=?, estado=?, activo=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sissi", $nombre, $rol_id, $estado, $activo, $id);
    }

    if ($stmt->execute()) {
        $_SESSION["msg_success"] = "Usuario actualizado correctamente.";
    } else {
        $_SESSION["msg_error"] = "Error al actualizar el usuario.";
    }

    header("Location: index.php?url=admin_usuarios");
    exit;
}

// ======================================================
//  ELIMINAR USUARIO
// ======================================================
if (isset($_GET["eliminar"])) {
    $id = intval($_GET["eliminar"]);

    // Verificar si tiene documentos asociados
    $check = $conn->prepare("SELECT COUNT(*) AS total FROM documentos WHERE id_capturista = ?");
    $check->bind_param("i", $id);
    $check->execute();
    $res = $check->get_result();
    $tieneDocs = $res->fetch_assoc()["total"];

    if ($tieneDocs > 0) {
        $_SESSION["msg_error"] = "No se puede eliminar: el usuario tiene documentos asociados.";
    } else {
        $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            $_SESSION["msg_success"] = "Usuario eliminado correctamente.";
        } else {
            $_SESSION["msg_error"] = "Error al eliminar el usuario.";
        }
    }

    header("Location: index.php?url=admin_usuarios");
    exit;
}

// ======================================================
//  CARGAR VISTA
// ======================================================
include dirname(__DIR__, 2) . "/app/views/admin/usuarios.php";
