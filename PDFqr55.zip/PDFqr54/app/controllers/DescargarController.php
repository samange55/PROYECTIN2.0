<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ======================================================
//  INCLUIR CONFIG Y HELPERS ANTES DE USAR FUNCIONES O $conn
// ======================================================
include "config/config.php";
require_once dirname(__DIR__, 2) . '/utils/helpers.php';

// ======================================================
//  Validar sesión del usuario
// ======================================================
if (!isset($_SESSION["usuario"])) {
    die("<div style='text-align:center;margin-top:50px;'>
            <h3 style='color:red;'> Debes iniciar sesión para acceder a esta función.</h3>
            <a href='index.php?url=login' style='color:#9F2241;'>Ir al login</a>
        </div>");
}

$usuario = $_SESSION["usuario"];

// ======================================================
//  Obtener ID del usuario logueado
// ======================================================
$sqlUser = "SELECT id FROM usuarios WHERE usuario = ?";
$stmtUser = $conn->prepare($sqlUser);
$stmtUser->bind_param("s", $usuario);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();
$id_usuario = ($row = $resultUser->fetch_assoc()) ? $row["id"] : 0;

// ======================================================
//  Validar permiso para DESCARGAR
// ======================================================
if (!tienePermiso($conn, $id_usuario, "puede_descargar")) {
    die("<div style='text-align:center;margin-top:80px;font-family:Arial;'>
            <h3 style='color:red;'> No tienes permiso para descargar documentos.</h3>
            <a href='index.php?url=documentos' style='color:#9F2241;text-decoration:none;'>Regresar</a>
        </div>");
}


$basePath = dirname(__DIR__, 2);

if (!defined('FPDF_FONTPATH')) {
    define('FPDF_FONTPATH', $basePath . '/lib/FPDF/font/');
}

require_once $basePath . '/lib/FPDF/fpdf.php';
require_once $basePath . '/lib/FPDI/src/autoload.php';
require_once $basePath . '/lib/phpqrcode/qrlib.php';

use setasign\Fpdi\Fpdi;

// ==========================
//  Validar ID del documento
// ==========================
if (!isset($_GET["id"]) || empty($_GET["id"])) {
    die("ID de documento no proporcionado.");
}

$id = $_GET["id"];

// ==========================
//  Consultar documento con JOINs normalizados
// ==========================
$sql = "SELECT d.*, 
               p.tipo_predio, p.colonia, p.direccion, p.contribuyente, p.clave_catastral,
               p.superficie_terreno, p.superficie_construccion,
               pa.base_gravable, pa.bimestre, pa.linea_captura,
               pa.recibo_oficial, pa.recibo_mejoras, pa.costo_certificacion,
               a.nombre AS subdirector, a.cargo
        FROM documentos d
        LEFT JOIN predios p ON d.id = p.documento_id
        LEFT JOIN pagos pa ON d.id = pa.documento_id
        LEFT JOIN autoridades a ON d.autoridad_id = a.id
        WHERE d.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $id);
$stmt->execute();
$result = $stmt->get_result();
$doc = $result->fetch_assoc();

if (!$doc) {
    die("Documento no encontrado o no válido.");
}

// ==========================
//  Validar estado del documento
// ==========================
if (isset($doc["estado_pdf"]) && $doc["estado_pdf"] === "cancelado") {
    die("Este documento ha sido cancelado y no es válido.");
}

// ==========================
//  Limpiar valores numéricos
// ==========================
$doc["superficie_terreno"] = rtrim(rtrim((string)$doc["superficie_terreno"], '0'), '.');
$doc["superficie_construccion"] = rtrim(rtrim((string)$doc["superficie_construccion"], '0'), '.');
$doc["costo_certificacion"] = rtrim(rtrim((string)$doc["costo_certificacion"], '0'), '.');
$doc["base_gravable"] = rtrim(rtrim((string)$doc["base_gravable"], '0'), '.');

// ==========================
//  Nombre del archivo
// ==========================
$filename = ucfirst($doc["tipo_documento"]) . "_" . $doc["id"] . ".pdf";
$savePath = __DIR__ . "/../../../public/validados/" . $filename;

// Eliminar versión anterior del PDF si existe para regenerarlo con los cambios recientes
if (file_exists($savePath)) {
    unlink($savePath);
}


// ==========================
//  Si ya existe → descargar directamente
// ==========================
if (file_exists($savePath)) {
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Pragma: no-cache");
    header("Content-Type: application/pdf");
    header("Content-Disposition: attachment; filename=\"" . $filename . "\"");
    readfile($savePath);
    exit;
}

// ==========================
//  Generar QR
// ==========================
$urlQR = buildAbsoluteUrl("index.php", [
    "url" => "ver_pdf",
    "id"  => $doc["id"]
]);

ob_start();
QRcode::png($urlQR, null, QR_ECLEVEL_M, 6, 2);
$imageData = ob_get_contents();
ob_end_clean();

$tmpQR = tempnam(sys_get_temp_dir(), 'qr_') . '.png';
file_put_contents($tmpQR, $imageData);

// ==========================
//  Seleccionar plantilla
// ==========================
$plantillaDir = dirname(__DIR__, 2) . '/plantillas/';
$plantilla = $plantillaDir . 'no_adeudo.pdf';

if ($doc["tipo_documento"] === "aportacion_mejoras") {
    $plantilla = $plantillaDir . 'aportacion_mejoras.pdf';
}

// Validación extra por seguridad
if (!file_exists($plantilla)) {
    die("❌ No se encontró la plantilla PDF en: " . htmlspecialchars($plantilla));
}


// ==========================
//  Crear PDF base
// ==========================
$pdf = new Fpdi();
$pdf->AddPage();
$pdf->setSourceFile($plantilla);
$tplIdx = $pdf->importPage(1);
$pdf->useTemplate($tplIdx, 0, 0, 210);

$pdf->SetFont("Arial", "", 12);
$pdf->SetTextColor(0, 0, 0);

// ==========================
//  Fechas
// ==========================
$fechaGeneracion = new DateTime($doc["fecha_captura"]);
$dia  = $fechaGeneracion->format("d");
$anio = $fechaGeneracion->format("Y");
$meses = [
    "01" => "ENERO", "02" => "FEBRERO", "03" => "MARZO",
    "04" => "ABRIL", "05" => "MAYO", "06" => "JUNIO",
    "07" => "JULIO", "08" => "AGOSTO", "09" => "SEPTIEMBRE",
    "10" => "OCTUBRE", "11" => "NOVIEMBRE", "12" => "DICIEMBRE"
];
$mes = $meses[$fechaGeneracion->format("m")];

// ==========================
//  BLOQUE → NO ADEUDO
// ==========================
if ($doc["tipo_documento"] === "no_adeudo") {
    $pdf->SetFont("Arial", "", 12);
    $pdf->SetXY(40, 144);
    $pdf->Cell(120, 10, utf8_decode($doc["contribuyente"]), 0, 0);

    $pdf->SetFont("Arial", "B", 14);
    $pdf->SetTextColor(255, 0, 0);
    $pdf->SetXY(165, 50.5);
    $pdf->Cell(40, 10, " " . $doc["folio_no_adeudo"], 0, 0);

    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetXY(40, 89);
    $pdf->Cell(30, 8, $doc["anio_fiscal"], 0, 0);
    $pdf->SetXY(150, 160.5);
    $pdf->Cell(30, 8, $doc["anio_fiscal"], 0, 0);

    $pdf->SetXY(65, 150);
    $pdf->Cell(60, 8, $doc["clave_catastral"], 0, 0);

    $pdf->SetFont('Arial', '', 8);
    $pdf->SetXY(18, 141.5);
    $texto = utf8_decode($doc["direccion"] . " " . $doc["colonia"]);
    $pdf->MultiCell(150, 6, $texto, 0, 'L');

    $pdf->SetFont('Arial', '', 9);
    $pdf->SetXY(18, 160.5);
    $pdf->Cell(40, 8, $doc["base_gravable"], 0, 0);

    $pdf->SetXY(95, 160.5);
    $pdf->Cell(40, 8, $doc["bimestre"], 0, 0);

    $pdf->SetXY(40, 165);
    $pdf->Cell(50, 8, $doc["linea_captura"], 0, 0);

    $pdf->SetXY(40, 170);
    $pdf->Cell(40, 8, utf8_decode($doc["superficie_terreno"] . " MTS"), 0, 0);

    $pdf->SetXY(150, 170);
    $pdf->Cell(40, 8, utf8_decode($doc["superficie_construccion"] . " MTS"), 0, 0);

    $pdf->SetXY(10, 180);
    $pdf->Cell(50, 8, utf8_decode("HAIX " . $doc["recibo_oficial"]), 0, 0);

    $pdf->SetXY(143, 180);
    $pdf->Cell(50, 8, $doc["costo_certificacion"], 0, 0);

    $pdf->SetXY(40, 68.5);
    $pdf->Cell(60, 8, utf8_decode($doc["subdirector"]), 0, 0);

    $pdf->SetXY(40, 74);
    $pdf->Cell(60, 8, utf8_decode($doc["cargo"]), 0, 0);

    $pdf->SetXY(120, 165);
    $pdf->Cell(60, 8, date('d/m/Y', strtotime($doc["fecha_expedicion_pago"])), 0, 0);

    $pdf->SetXY(67, 213);
    $pdf->Cell(15, 8, $dia, 0, 0);
    $pdf->SetXY(117, 213);
    $pdf->Cell(40, 8, $mes, 0, 0);
    $pdf->SetXY(150, 213);
    $pdf->Cell(20, 8, $anio, 0, 0);
}

// ==========================
//  BLOQUE → APORTACIÓN A MEJORAS
// ==========================
if ($doc["tipo_documento"] === "aportacion_mejoras") {
    $pdf->SetFont("Arial", "", 12);
    $pdf->SetXY(45, 139.5);
    $pdf->Cell(120, 10, utf8_decode($doc["contribuyente"]), 0, 0);

    $pdf->SetFont("Arial", "B", 14);
    $pdf->SetTextColor(255, 0, 0);
    $pdf->SetXY(166, 50.5);
    $pdf->Cell(40, 10, " " . $doc["folio_aportacion"], 0, 0);

    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFont("Arial", "", 12);
    $pdf->SetXY(35, 89.5);
    $pdf->Cell(30, 8, $doc["anio_fiscal"], 0, 0);

    $pdf->SetXY(128, 135.5);
    $pdf->Cell(80, 8, $doc["clave_catastral"], 0, 0);

    $pdf->SetFont('Arial', '', 8);
    $pdf->SetXY(82, 131.5);
    $texto = utf8_decode($doc["direccion"] . " " . $doc["colonia"]);
    $pdf->MultiCell(150, 6, $texto, 0, 'L');

    $pdf->SetFont("Arial", "", 12);
    $pdf->SetXY(25, 188.5);
    $pdf->Cell(50, 8, utf8_decode("HAIX " . $doc["recibo_oficial"]), 0, 0);

    $pdf->SetXY(25, 194);
    $pdf->Cell(40, 8, $doc["costo_certificacion"], 0, 0);

    $pdf->SetXY(35, 69.5);
    $pdf->Cell(60, 8, utf8_decode($doc["subdirector"]), 0, 0);

    $pdf->SetXY(35, 74.5);
    $pdf->Cell(60, 8, utf8_decode($doc["cargo"]), 0, 0);

    $pdf->SetXY(68, 213);
    $pdf->Cell(15, 8, $dia, 0, 0);
    $pdf->SetXY(119, 213.5);
    $pdf->Cell(40, 8, $mes, 0, 0);
    $pdf->SetXY(150, 213.5);
    $pdf->Cell(20, 8, $anio, 0, 0);
}

// ==========================
//  Insertar QR y guardar
// ==========================
$pdf->Image($tmpQR, 170, 230, 28, 28);
unlink($tmpQR);

if (!file_exists(dirname($savePath))) {
    mkdir(dirname($savePath), 0777, true);
}

$pdf->Output("F", $savePath);

// ==========================
//  Descargar directamente
// ==========================
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
$pdf->Output("D", $filename);
exit;
