<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include_once dirname(__DIR__, 3) . "/config/config.php"; // Conexión a BD

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $usuario = trim($_POST["usuario"]);
    $password = trim($_POST["password"]);

    // Buscar usuario en la base de datos
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE usuario = ?");
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();

        if (password_verify($password, $row["password"])) {
            //  Crear sesión con datos del usuario
            $_SESSION["usuario"] = $row["usuario"];
            $_SESSION["rol_id"]  = $row["rol_id"];
            $_SESSION["nombre"]  = $row["nombre"];
            $_SESSION["activo"]  = $row["activo"];

            // Solo si está activo
            if ($row["activo"] != 1) {
                $_SESSION["msg_error"] = "El usuario está deshabilitado.";
                header("Location: index.php?url=login");
                exit;
            }

            //  Redirigir según rol
            if ($row["rol_id"] == 1) {
                header("Location: index.php?url=admin");
            } else {
                header("Location: index.php?url=documentos");
            }
            exit;

        } else {
            $_SESSION["msg_error"] = "Contraseña incorrecta.";
        }
    } else {
        $_SESSION["msg_error"] = "Usuario no encontrado.";
    }
}
?>


<?php include dirname(__DIR__, 2) . "/views/layout/header.php"; ?>

<h3 class="text-center">Subdirección de Recaudación</h3>
<div class="row justify-content-center">
  <div class="col-md-4">
    <div class="card p-4 shadow">
      <h3 class="text-center">Iniciar Sesión</h3>

      <?php if (isset($_SESSION["msg_error"])): ?>
      <div class="alert alert-danger">
      <?= $_SESSION["msg_error"]; unset($_SESSION["msg_error"]); ?>
      </div>
      <?php endif; ?>


      <form method="post">
        <div class="mb-3">
          <label class="form-label">Usuario</label>
          <input type="text" name="usuario" class="form-control" required>
        </div>
        <div class="mb-3">
          <label for="password" class="form-label">Contraseña</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Ingresar</button>
      </form>

      <!--p class="mt-3 text-center">
        ¿No tienes cuenta?
        <a href="index.php?url=registro">Registrar nuevo usuario</a>
      </p>-->
    </div>
  </div>
</div>
