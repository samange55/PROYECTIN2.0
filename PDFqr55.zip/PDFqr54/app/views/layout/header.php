<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once dirname(__DIR__, 3) . "/config/config.php"; 
require_once dirname(__DIR__, 3) . "/utils/helpers.php"; 

// (El header ya no carga documentos, eso queda en DocumentosController.php)
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Captura de Documentos</title>
    <link rel="icon" href="<?php echo buildAbsoluteUrl('public/assets/img/favicon.ico'); ?>" type="image/x-icon"> 
    <link rel="stylesheet" href="<?php echo buildAbsoluteUrl('public/assets/css/bootstrap.min.css'); ?>">
    <!-- Bootstrap 5 -->
    <style>
        body {
            background-color: #f4f4f4;
        }
        .navbar {
            background-color: #9F2241;
        }
        .navbar-brand, .nav-link, .navbar-text {
            color: #fff !important;
        }
        .card {
            border-radius: 12px;
            box-shadow: 0px 2px 6px rgba(15, 18, 15, 0.1);
        }
        .btn-primary {
            background-color: #BC955C;
            border: none;
        }
        .btn-primary:hover {
            background-color: #a58343ff;
        }
        footer {
            background: #003366;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 30px;
        }
        .btn-docs, .btn-logout, .btn-new-doc {
            background: none;
            border: none;
            color: #fff;
            font-size: 1rem;
            cursor: pointer;
            padding: 0;
            transition: color 0.3s ease;
        }
        .btn-docs:hover, .btn-logout:hover, .btn-new-doc:hover {
            color: #ffd700;
            text-decoration: none;
        }
        .section-card {
            background: #fff;
            border-radius: 10px;
            padding: 20px 25px;
            margin-bottom: 25px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            border-left: 6px solid #9F2241;
        }

        .section-card h5 {
           border-bottom: 2px solid #BC955C;
           padding-bottom: 6px;
           margin-bottom: 15px;
           color: #9F2241;
        }
        /* ==== BOTÓN FINAL ==== */
        .btn-guardar {
            background-color: #BC955C !important;  /* tono institucional dorado */
            border: none;
            color: #fff;
            font-weight: 500;
            padding: 10px 0; /* altura más reducida */
            border-radius: 8px;
            transition: all 0.2s ease-in-out;
            margin-bottom: 40px; /* separación del borde inferior */
        }

        .btn-guardar:hover {
            background-color: #9F2241 !important;  /* cambia a rojo institucional */
            transform: scale(1.03);
        }

        /* ====== EFECTO DE BLOQUEO EN CAMPOS ====== */
        .readonly {
            background-color: #f1f1f1 !important;
            color: #777 !important;
            pointer-events: none;
            border-color: #ddd !important;
            transition: all 0.3s ease-in-out;
        }

        /* Animación cuando se cambia el estado */
            input.form-control, select.form-select {
            transition: all 0.25s ease-in-out;
        }
        .container h3 {
            color: #9F2241;
            font-weight: 600;
        }

        
</style>

</head>
<body>
<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand d-flex align-items-center" href="index.php?url=dashboard">
      <img src="<?php echo buildAbsoluteUrl('public/assets/img/IXTALOGO.png'); ?>" 
           alt="Logo" height="40" class="me-2">
      Sistema de Validación de Documentos
    </a>

    <?php if (isset($_SESSION["usuario"])): ?>
    <?php
        // Información de sesión
        $usuario = $_SESSION["usuario"] ?? 'Invitado';
        $rol     = $_SESSION["rol"] ?? 'Desconocido';
        $nombre  = $_SESSION["nombre"] ?? '';

        // Texto para mostrar (elegante y legible)
        $textoSesion = ($rol === 'admin')
            ? "Administrador: " . htmlspecialchars($nombre ?: $usuario)
            : "Capturista: " . htmlspecialchars($nombre ?: $usuario);
    ?>
    <ul class="navbar-nav ms-auto d-flex align-items-center">
        <li class="nav-item me-4 text-white fw-semibold">
            <i class="bi bi-person-circle"></i>
            <?= $textoSesion; ?>
        </li>
        <li class="nav-item me-3">
            <a href="index.php?url=dashboard" class="btn-new-doc">Nuevo Documento</a>
        </li>
        <li class="nav-item me-3">
            <a href="index.php?url=documentos" class="btn-docs">Documentos capturados</a>
        </li>
        <li class="nav-item">
            <a href="index.php?url=logout" class="btn-logout">
                <i class="bi bi-box-arrow-right"></i> Cerrar sesión
            </a>
        </li>
    </ul>
    <?php endif; ?>
  </div>
</nav>


<div class="container mt-4">
