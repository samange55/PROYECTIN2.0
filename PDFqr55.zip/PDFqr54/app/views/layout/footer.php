</div>

<script src="<?php echo buildAbsoluteUrl('public/assets/js/bootstrap.bundle.min.js'); ?>"></script>

</body>
</html>
