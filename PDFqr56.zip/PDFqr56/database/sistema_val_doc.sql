-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-10-2025 a las 07:04:33
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistema_val_doc`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `autoridades`
--

CREATE TABLE `autoridades` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `cargo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `autoridades`
--

INSERT INTO `autoridades` (`id`, `nombre`, `cargo`) VALUES
(5, 'JOSÉ MANUEL LÓPEZ CORTES', 'SUBDIRECTOR DE RECAUDACIÓN');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documentos`
--

CREATE TABLE `documentos` (
  `id` char(36) NOT NULL,
  `fecha_captura` date NOT NULL,
  `fecha_expedicion_pago` date DEFAULT NULL,
  `id_capturista` int(11) NOT NULL,
  `folio_no_adeudo` varchar(50) DEFAULT NULL,
  `folio_aportacion` varchar(50) DEFAULT NULL,
  `autoridad_id` int(11) DEFAULT NULL,
  `anio_fiscal` int(11) DEFAULT 2025,
  `tipo_documento` enum('no_adeudo','aportacion_mejoras') DEFAULT NULL,
  `ruta_pdf` varchar(255) DEFAULT NULL,
  `url_validacion` varchar(255) DEFAULT NULL,
  `estado_pdf` enum('activo','cancelado') DEFAULT 'activo',
  `estado_entrega` enum('pendiente','entregado') DEFAULT 'pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `documentos`
--

INSERT INTO `documentos` (`id`, `fecha_captura`, `fecha_expedicion_pago`, `id_capturista`, `folio_no_adeudo`, `folio_aportacion`, `autoridad_id`, `anio_fiscal`, `tipo_documento`, `ruta_pdf`, `url_validacion`, `estado_pdf`, `estado_entrega`) VALUES
('68f2df7751cd16.19135792', '2025-10-17', '2025-10-17', 2, '500', '3252654643234325254', 5, 2025, 'no_adeudo', NULL, NULL, 'activo', 'pendiente'),
('68f2dfb547b489.27755214', '2025-10-17', '2025-10-17', 2, '', '501', 5, 2025, 'aportacion_mejoras', NULL, NULL, 'activo', 'pendiente'),
('68f2e4df603d02.15624311', '2025-10-17', '2025-10-17', 2, '502', '', 5, 2025, 'no_adeudo', NULL, NULL, 'activo', 'pendiente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial_acciones`
--

CREATE TABLE `historial_acciones` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `accion` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

CREATE TABLE `pagos` (
  `id` int(11) NOT NULL,
  `documento_id` char(36) NOT NULL,
  `base_gravable` decimal(12,2) DEFAULT NULL,
  `bimestre` int(11) DEFAULT NULL,
  `linea_captura` varchar(100) DEFAULT NULL,
  `recibo_oficial` varchar(50) DEFAULT NULL,
  `recibo_mejoras` varchar(50) DEFAULT NULL,
  `costo_certificacion` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pagos`
--

INSERT INTO `pagos` (`id`, `documento_id`, `base_gravable`, `bimestre`, `linea_captura`, `recibo_oficial`, `recibo_mejoras`, `costo_certificacion`) VALUES
(5, '68f2df7751cd16.19135792', 9999999999.99, 1, '598012345678901234153234', '35834760509856', '04856034833453453', 1000.00),
(6, '68f2dfb547b489.27755214', 9999999999.99, 1, '598012345678901234153234', '35834760509856', '04856034833453453', 1000.00),
(7, '68f2e4df603d02.15624311', 9999999999.99, 1, '5980123456789012341532342', '358347605098561', '04856034833453452', 1000.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permisos_usuarios`
--

CREATE TABLE `permisos_usuarios` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `puede_ver` tinyint(1) DEFAULT 1,
  `puede_editar` tinyint(1) DEFAULT 0,
  `puede_cancelar` tinyint(1) DEFAULT 0,
  `puede_recuperar` tinyint(1) DEFAULT 0,
  `puede_entregar` tinyint(1) DEFAULT 0,
  `puede_revocar_entrega` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `permisos_usuarios`
--

INSERT INTO `permisos_usuarios` (`id`, `usuario_id`, `puede_ver`, `puede_editar`, `puede_cancelar`, `puede_recuperar`, `puede_entregar`, `puede_revocar_entrega`) VALUES
(1, 2, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `predios`
--

CREATE TABLE `predios` (
  `id` int(11) NOT NULL,
  `documento_id` char(36) NOT NULL,
  `tipo_predio` varchar(50) DEFAULT NULL,
  `colonia` varchar(100) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `contribuyente` varchar(100) DEFAULT NULL,
  `clave_catastral` varchar(50) DEFAULT NULL,
  `superficie_terreno` decimal(10,2) DEFAULT NULL,
  `superficie_construccion` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `predios`
--

INSERT INTO `predios` (`id`, `documento_id`, `tipo_predio`, `colonia`, `direccion`, `contribuyente`, `clave_catastral`, `superficie_terreno`, `superficie_construccion`) VALUES
(5, '68f2df7751cd16.19135792', 'SIN CONSTRUIR', '18 DE AGOSTO', 'METEPETL, 56537 IXTAPALUCA, MÉX', 'EDUARDO BEJARANO LEAL', '150870123456789', 1000.00, 500.00),
(6, '68f2dfb547b489.27755214', 'CONSTRUIDO', 'CUMBRES DE LA MONTAÑA', 'Metepetl, 56537 Ixtapaluca, Méx,', 'FRAGA FLORES MARCO EMILIANO', '150870123456789', 1000.00, 500.00),
(7, '68f2e4df603d02.15624311', 'CONSTRUIDO', 'AMPLIACIÓN PLUTARCO ELÍAS CALLES', 'Metepetl, 56537 Ixtapaluca, Méx,', 'ARTURITO FLORES HERNANDEZ', '150870123456781', 1000.00, 500.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` tinyint(4) NOT NULL,
  `nombre` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `nombre`) VALUES
(1, 'admin'),
(2, 'capturista');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `rol_id` tinyint(4) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `estado` enum('activo','afk','inactivo') DEFAULT 'activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `password`, `nombre`, `rol_id`, `activo`, `estado`) VALUES
(2, 'administrador', '$2y$10$tkT5QXNTlzyUUlmZLG5e1.yXfHSMkJrD8DGYBbEYMrueOu/tyEV3S', 'Marco miller', 2, 1, 'activo'),
(8, 'admin', '$2y$10$oa17FQDyhk5YSQ4.lKcOI.LVwbhGoBvFb4ACq5/6RX6AYAESjaj9G', 'Administrador del sistema', 1, 1, 'activo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `autoridades`
--
ALTER TABLE `autoridades`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `documentos`
--
ALTER TABLE `documentos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_doc_autoridad` (`autoridad_id`),
  ADD KEY `idx_documentos_capturista` (`id_capturista`);

--
-- Indices de la tabla `historial_acciones`
--
ALTER TABLE `historial_acciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_pagos_doc` (`documento_id`);

--
-- Indices de la tabla `permisos_usuarios`
--
ALTER TABLE `permisos_usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unico_usuario` (`usuario_id`);

--
-- Indices de la tabla `predios`
--
ALTER TABLE `predios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_predios_doc` (`documento_id`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`),
  ADD KEY `fk_usuarios_roles` (`rol_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `autoridades`
--
ALTER TABLE `autoridades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `historial_acciones`
--
ALTER TABLE `historial_acciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pagos`
--
ALTER TABLE `pagos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `permisos_usuarios`
--
ALTER TABLE `permisos_usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `predios`
--
ALTER TABLE `predios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `documentos`
--
ALTER TABLE `documentos`
  ADD CONSTRAINT `fk_doc_autoridad` FOREIGN KEY (`autoridad_id`) REFERENCES `autoridades` (`id`),
  ADD CONSTRAINT `fk_doc_usuarios` FOREIGN KEY (`id_capturista`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `historial_acciones`
--
ALTER TABLE `historial_acciones`
  ADD CONSTRAINT `historial_acciones_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD CONSTRAINT `fk_pagos_documentos` FOREIGN KEY (`documento_id`) REFERENCES `documentos` (`id`);

--
-- Filtros para la tabla `permisos_usuarios`
--
ALTER TABLE `permisos_usuarios`
  ADD CONSTRAINT `permisos_usuarios_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `predios`
--
ALTER TABLE `predios`
  ADD CONSTRAINT `fk_predios_documentos` FOREIGN KEY (`documento_id`) REFERENCES `documentos` (`id`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_usuarios_roles` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
