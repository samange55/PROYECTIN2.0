<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ======================================================
//  OBTENER URL SOLICITADA
// ======================================================
$url = $_GET["url"] ?? "login";

// ======================================================
//  CARGAR ARCHIVO DE RUTAS (ubicado junto a index.php)
// ======================================================
$routesPath = __DIR__ . "/routes.php";

if (!file_exists($routesPath)) {
    die("<h3 style='color:red;text-align:center;margin-top:20%;'>
            Error: archivo de rutas no encontrado (<code>routes.php</code>)
         </h3>");
}

$routes = include $routesPath;

// ======================================================
//  VERIFICAR Y CARGAR RUTA
// ======================================================
if (array_key_exists($url, $routes)) {

    $ruta = $routes[$url];

    // Verificar si el archivo existe físicamente
    if (file_exists($ruta)) {
        include $ruta;
    } else {
        echo "<h3 style='color:red;text-align:center;margin-top:20%;'>
                Archivo no encontrado:<br><code>$ruta</code>
              </h3>";
    }

} else {
    echo "<h3 style='color:red;text-align:center;margin-top:20%;'>
            Página no encontrada: <code>" . htmlspecialchars($url) . "</code>
          </h3>";
}
