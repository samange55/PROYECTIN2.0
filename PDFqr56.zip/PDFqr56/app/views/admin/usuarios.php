<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Administración de Usuarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        .navbar { background-color: #9F2241; }
        .navbar-brand, .nav-link { color: white !important; }
        .nav-link:hover, .nav-link.active {
            background-color: #BC955C;
            border-radius: 8px;
        }
        .card {
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            margin-bottom: 1rem;
        }
        .card-header {
            background-color: #9F2241;
            color: white;
            font-weight: bold;
        }
        .btn-primary {
            background-color: #9F2241;
            border-color: #9F2241;
        }
        .btn-primary:hover {
            background-color: #BC955C;
            border-color: #BC955C;
        }
    </style>
</head>
<body>

<!-- NAVBAR superior -->
<nav class="navbar navbar-expand-lg mb-4">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php?url=admin"><i class="bi bi-speedometer2"></i> Panel de Administración</a>
    <div class="collapse navbar-collapse" id="navbarAdmin">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a href="index.php?url=admin_usuarios" class="nav-link active"><i class="bi bi-people-fill"></i> Usuarios</a></li>
        <li class="nav-item"><a href="index.php?url=documentos" class="nav-link"><i class="bi bi-file-earmark-text"></i> Documentos</a></li>
        <li class="nav-item"><a href="index.php?url=logout" class="nav-link text-danger"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container">

  <!-- Mensajes de éxito o error -->
  <?php if (isset($_SESSION["msg_success"])): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $_SESSION["msg_success"]; unset($_SESSION["msg_success"]); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
  <?php elseif (isset($_SESSION["msg_error"])): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $_SESSION["msg_error"]; unset($_SESSION["msg_error"]); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
  <?php endif; ?>

  <!-- Tarjeta principal -->
  <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
      <span><i class="bi bi-people"></i> Gestión de Usuarios</span>
      <button class="btn btn-success btn-sm" data-bs-toggle="collapse" data-bs-target="#nuevoUsuario">
        <i class="bi bi-plus-circle"></i> Nuevo Usuario
      </button>
    </div>
    <div class="card-body">

      <!-- FORMULARIO NUEVO USUARIO -->
      <div id="nuevoUsuario" class="collapse mb-4">
        <form method="POST">
          <input type="hidden" name="crear" value="1">
          <div class="row g-3">
            <div class="col-md-3">
              <label class="form-label">Usuario</label>
              <input type="text" name="usuario" class="form-control" required>
            </div>
            <div class="col-md-3">
              <label class="form-label">Nombre completo</label>
              <input type="text" name="nombre" class="form-control" required>
            </div>
            <div class="col-md-3">
              <label class="form-label">Contraseña</label>
              <input type="password" name="password" class="form-control" required>
            </div>
            <div class="col-md-3">
              <label class="form-label">Rol</label>
              <select name="rol_id" class="form-select" required>
                <?php while ($r = $roles->fetch_assoc()): ?>
                  <option value="<?= $r['id'] ?>"><?= ucfirst($r['nombre']) ?></option>
                <?php endwhile; ?>
              </select>
            </div>
            <div class="col-md-3">
              <label class="form-label">Estado</label>
              <select name="estado" class="form-select">
                <option value="activo">Activo</option>
                <option value="afk">AFK</option>
                <option value="inactivo">Inactivo</option>
              </select>
            </div>
            <div class="col-md-2 form-check mt-4">
              <input class="form-check-input" type="checkbox" name="activo" checked>
              <label class="form-check-label">Activo</label>
            </div>
            <div class="col-md-2 mt-4 text-end">
              <button type="submit" class="btn btn-primary w-100"><i class="bi bi-save"></i> Guardar</button>
            </div>
          </div>
        </form>
      </div>

      <!-- TABLA DE USUARIOS -->
      <div class="table-responsive">
        <table class="table table-hover align-middle text-center">
          <thead class="table-dark">
            <tr>
              <th>ID</th>
              <th>Usuario</th>
              <th>Nombre</th>
              <th>Rol</th>
              <th>Estado</th>
              <th>Activo</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            <?php while ($u = $usuarios->fetch_assoc()): ?>
            <tr>
              <td><?= $u['id'] ?></td>
              <td><?= htmlspecialchars($u['usuario']) ?></td>
              <td><?= htmlspecialchars($u['nombre']) ?></td>
              <td><?= ucfirst($u['rol_nombre']) ?></td>
              <td><span class="badge bg-<?= $u['estado']=='activo'?'success':($u['estado']=='afk'?'warning':'secondary') ?>"><?= ucfirst($u['estado']) ?></span></td>
              <td><?= $u['activo'] ? 'Sí' : 'No' ?></td>
              <td>
                <!-- BOTÓN EDITAR -->
                <button class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editarUsuario<?= $u['id'] ?>">
                  <i class="bi bi-pencil-square"></i>
                </button>

                <!-- BOTÓN ELIMINAR -->
                <a href="index.php?url=admin_usuarios&eliminar=<?= $u['id'] ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('¿Eliminar este usuario?')">
                  <i class="bi bi-trash"></i>
                </a>
              </td>
            </tr>

            <!-- MODAL EDITAR USUARIO -->
            <div class="modal fade" id="editarUsuario<?= $u['id'] ?>" tabindex="-1" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="bi bi-pencil-square"></i> Editar Usuario</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                  </div>
                  <form method="POST">
                    <div class="modal-body">
                      <input type="hidden" name="editar" value="1">
                      <input type="hidden" name="id" value="<?= $u['id'] ?>">

                      <div class="mb-3">
                        <label class="form-label">Nombre completo</label>
                        <input type="text" name="nombre" value="<?= htmlspecialchars($u['nombre']) ?>" class="form-control" required>
                      </div>
                      <div class="mb-3">
                        <label class="form-label">Nueva contraseña (opcional)</label>
                        <input type="password" name="password" class="form-control">
                      </div>
                      <div class="mb-3">
                        <label class="form-label">Rol</label>
                        <select name="rol_id" class="form-select">
                          <option value="1" <?= $u['rol_nombre']=='admin'?'selected':'' ?>>Admin</option>
                          <option value="2" <?= $u['rol_nombre']=='capturista'?'selected':'' ?>>Capturista</option>
                        </select>
                      </div>
                      <div class="mb-3">
                        <label class="form-label">Estado</label>
                        <select name="estado" class="form-select">
                          <option value="activo" <?= $u['estado']=='activo'?'selected':'' ?>>Activo</option>
                          <option value="afk" <?= $u['estado']=='afk'?'selected':'' ?>>AFK</option>
                          <option value="inactivo" <?= $u['estado']=='inactivo'?'selected':'' ?>>Inactivo</option>
                        </select>
                      </div>
                      <div class="form-check">
                        <input type="checkbox" class="form-check-input" name="activo" <?= $u['activo'] ? 'checked' : '' ?>>
                        <label class="form-check-label">Usuario activo</label>
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button type="submit" class="btn btn-success"><i class="bi bi-save"></i> Guardar</button>
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
