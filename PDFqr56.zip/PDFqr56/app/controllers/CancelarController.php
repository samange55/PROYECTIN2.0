<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include_once dirname(__DIR__, 2) . "/config/config.php";
include_once dirname(__DIR__, 2) . "/utils/helpers.php";

// ==========================
//  Verificar usuario logueado
// ==========================
if (!isset($_SESSION["usuario"])) {
    header("Location: index.php?url=login");
    exit;
}

$usuario = $_SESSION["usuario"];

// ==========================
//  Obtener ID del capturista
// ==========================
$sqlUser = "SELECT id FROM usuarios WHERE usuario = ?";
$stmtUser = $conn->prepare($sqlUser);
$stmtUser->bind_param("s", $usuario);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();
$id_capturista = ($row = $resultUser->fetch_assoc()) ? $row["id"] : 0;

// ==========================
//  Validar permiso
// ==========================
if (!tienePermiso($conn, $id_capturista, "puede_cancelar")) {
    die("<div style='text-align:center;margin-top:50px;'>
            <h3 style='color:red;'> No tienes permiso para cancelar documentos.</h3>
            <a href='index.php?url=documentos' style='color:#9F2241;'>Regresar</a>
        </div>");
}

// ==========================
//  Validar ID del documento
// ==========================
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Falta el ID del documento.");
}
$id = $_GET['id'];

// ==========================
//  Verificar existencia del documento
// ==========================
$sqlDoc = "SELECT id, tipo_documento FROM documentos WHERE id = ?";
$stmtDoc = $conn->prepare($sqlDoc);
$stmtDoc->bind_param("s", $id);
$stmtDoc->execute();
$result = $stmtDoc->get_result();
$doc = $result->fetch_assoc();

if (!$doc) {
    die("Documento no encontrado o no válido.");
}

// ==========================
//  Construir ruta del PDF
// ==========================
$carpetaValidados = dirname(__DIR__, 2) . "/public/validados/";
$filename = ucfirst($doc["tipo_documento"]) . "_" . $doc["id"] . ".pdf";
$rutaPDF = $carpetaValidados . $filename;

// ==========================
//  Eliminar archivo físico
// ==========================
if (file_exists($rutaPDF)) {
    unlink($rutaPDF);
}

// ==========================
//  Actualizar estado en BD
// ==========================
$sqlUpdate = "UPDATE documentos SET estado_pdf = 'cancelado' WHERE id = ?";
$stmtUpdate = $conn->prepare($sqlUpdate);
$stmtUpdate->bind_param("s", $id);
$stmtUpdate->execute();

// ==========================
//  Confirmar y redirigir
// ==========================
$_SESSION["msg"] = "Documento cancelado correctamente.";
header("Location: index.php?url=documentos");
exit;
