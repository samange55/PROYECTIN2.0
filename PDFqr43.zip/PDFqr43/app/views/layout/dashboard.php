<?php
session_start();
include "config/config.php";

if (!isset($_SESSION["usuario"])) {
    header("Location: login.php");
    exit;
}

// Función para obtener el id del usuario logueado
function getUserId($usuario, $conn) {
    $sql = "SELECT id FROM QRusuarios WHERE usuario = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        return $row["id"];
    }
    return null;
}

$id_capturista = getUserId($_SESSION["usuario"], $conn);

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// Variables para mostrar BOTONES 
$tipo_doc_guardado = null;
$id_doc_guardado   = null;
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

// Insertar documento si se envía formulario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["guardar_doc"])) {
    $fecha_captura = $_POST["fecha_captura"];
    $anio_fiscal = $_POST["anio_fiscal"];
    $tipo_documento = $_POST["tipo_documento"];
    $folio_no_adeudo = $_POST["folio_no_adeudo"];
    $folio_aportacion = $_POST["folio_aportacion"];
    $linea_captura = $_POST["linea_captura"];
    $tipo_predio = $_POST["tipo_predio"];

    // Manejo de colonia y colonia_otro
    $colonia = $_POST["colonia"];
    $colonia_otro = isset($_POST["colonia_otro"]) ? $_POST["colonia_otro"] : null;
    if ($colonia === "Otro" && !empty($colonia_otro)) {
        $colonia = $colonia_otro;
    }

    $direccion = $_POST["direccion"];
    $contribuyente = $_POST["contribuyente"];
    $clave_catastral = $_POST["clave_catastral"];
    $base_gravable = $_POST["base_gravable"];
    $bimestre = $_POST["bimestre"];
    $superficie_terreno = $_POST["superficie_terreno"];
    $superficie_construccion = $_POST["superficie_construccion"];
    $subdirector = $_POST["subdirector"];
    $cargo = $_POST["cargo"];
    $recibo_oficial = $_POST["recibo_oficial"];
    $recibo_mejoras = $_POST["recibo_mejoras"];
    $costo_certificacion = $_POST["costo_certificacion"];

    // ======================================================
    // Consulta preparada
    // ======================================================
    $sql = "INSERT INTO QRdocumentos (
        id, fecha_captura, id_capturista, anio_fiscal, tipo_documento,
        folio_no_adeudo, folio_aportacion, linea_captura,
        tipo_predio, colonia, direccion, clave_catastral,
        base_gravable, bimestre, superficie_terreno, superficie_construccion,
        contribuyente, subdirector, cargo, recibo_oficial, recibo_mejoras, costo_certificacion
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Error en la preparación de la consulta: " . $conn->error);
    }

    //  Caso especial: AMBOS
    if ($tipo_documento === "ambos") {
        // ---- Primer documento → No adeudo ----
        $id1 = uniqid("", true);
        $tipo1 = "no_adeudo";
        $stmt->bind_param(
            "ssissssssssssdiisdssss",
            $id1, $fecha_captura, $id_capturista, $anio_fiscal, $tipo1,
            $folio_no_adeudo, $folio_aportacion, $linea_captura,
            $tipo_predio, $colonia, $direccion, $clave_catastral,
            $base_gravable, $bimestre, $superficie_terreno, $superficie_construccion,
            $contribuyente, $subdirector, $cargo,
            $recibo_oficial, $recibo_mejoras, $costo_certificacion
        );
        $stmt->execute();

        // ---- Segundo documento → Aportación a mejoras ----
        $id2 = uniqid("", true);
        $tipo2 = "aportacion_mejoras";
        $stmt->bind_param(
            "ssissssssssssdiisdssss",
            $id2, $fecha_captura, $id_capturista, $anio_fiscal, $tipo2,
            $folio_no_adeudo, $folio_aportacion, $linea_captura,
            $tipo_predio, $colonia, $direccion, $clave_catastral,
            $base_gravable, $bimestre, $superficie_terreno, $superficie_construccion,
            $contribuyente, $subdirector, $cargo,
            $recibo_oficial, $recibo_mejoras, $costo_certificacion
        );
        $stmt->execute();

        $msg = " Se generaron ambos documentos correctamente.";
        $tipo_doc_guardado = "ambos";
        $ids_ambos = [$id1, $id2]; // guardamos ambos IDs para usarlos en el botón

    } else {
        // ======================================================
        // Caso normal → solo un documento
        // ======================================================
        $id = uniqid("", true);
        $stmt->bind_param(
            "ssissssssssssdiisdssss",
            $id, $fecha_captura, $id_capturista, $anio_fiscal, $tipo_documento,
            $folio_no_adeudo, $folio_aportacion, $linea_captura,
            $tipo_predio, $colonia, $direccion, $clave_catastral,
            $base_gravable, $bimestre, $superficie_terreno, $superficie_construccion,
            $contribuyente, $subdirector, $cargo,
            $recibo_oficial, $recibo_mejoras, $costo_certificacion
        );

        if ($stmt->execute()) {
            $msg = " Documento guardado correctamente.";
            $id_doc_guardado   = $id;
            $tipo_doc_guardado = $tipo_documento;
            $no_adeudo_lleno   = !empty($folio_no_adeudo);
            $aportacion_lleno  = !empty($folio_aportacion);
        } else {
            $error = " Error: " . $conn->error;
        }
    }
}


?>
<?php include "app/views/layout/header.php"; ?>

<div class="row justify-content-center">
  <div class="col-lg-10">
    <div class="card p-4 mb-4">
      <h4 class="text-center">Registrar Nuevo Documento</h4>
      <?php if (isset($msg)) { ?>
        <div class="alert alert-success"><?php echo $msg; ?></div>

        <!-- ========================================= -->
        <!-- BOTONES de impresión condicionales -->
        <?php if (isset($msg)) { ?>
  <div class="alert alert-success"><?php echo $msg; ?></div>

  <!--  Botones de impresión condicionales -->
  <div class="text-center mb-3">
<!-- Si el documento guardado es de tipo no_adeudo -->
<?php if ($tipo_doc_guardado === "no_adeudo" && $no_adeudo_lleno) { ?>
  <a href="index.php?url=ver_pdf&id=<?php echo $id_doc_guardado; ?>" target="_blank" class="btn btn-success me-2">
    Imprimir No Adeudo predial
  </a>
<?php } ?>

<!-- Si el documento guardado es de tipo aportacion_mejoras -->
<?php if ($tipo_doc_guardado === "aportacion_mejoras" && $aportacion_lleno) { ?>
  <a href="index.php?url=ver_pdf&id=<?php echo $id_doc_guardado; ?>" target="_blank" class="btn btn-warning me-2">
    Imprimir Aportación a Mejoras
  </a>
<?php } ?>

<!-- Si el documento guardado es "ambos" -->
<?php if ($tipo_doc_guardado === "ambos" && !empty($ids_ambos)) { ?>
  <a href="index.php?url=ver_pdf_ambos&id1=<?php echo $ids_ambos[0]; ?>&id2=<?php echo $ids_ambos[1]; ?>" 
   target="_blank" 
   class="btn btn-primary">
   Imprimir Ambos Documentos
</a>
<?php } ?>

  </div>
  
<?php } ?>

        <!-- ========================================= -->

      <?php } ?>
      <?php if (isset($error)) { ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
      <?php } ?>

      <form method="post" class="row g-3">
        <!-- Datos del documento -->
        <h5 class="mt-3">Datos del documento</h5>
        <div class="col-md-4">
          <label class="form-label">Fecha de Expedicion de  Pago</label>
          <input type="date" name="fecha_captura" value="<?php echo date('d-m-Y'); ?>" class="form-control" required>
        </div>
        <div class="col-md-4">
          <label class="form-label">Año fiscal</label>
          <input type="number" name="anio_fiscal" value="2025" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Tipo de documento</label>
          <select name="tipo_documento" class="form-select">
            <option value="no_adeudo">No adeudo predial</option>
            <option value="aportacion_mejoras">Aportación a mejoras</option>
            <option value="ambos">Llenar Ambos</option>
          </select>
        </div>

        <!-- Identificación y folios -->
        <h5 class="mt-3">Identificación y folios</h5>
        <div class="col-md-4">
          <label class="form-label">Folio No adeudo predial</label>
          <input type="text" name="folio_no_adeudo" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Folio Aportación</label>
          <input type="text" name="folio_aportacion" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Línea de captura</label>
          <input type="text" name="linea_captura" class="form-control">
        </div>

        <!-- Datos del predio -->
        <h5 class="mt-3">Datos del predio</h5>
        <div class="col-md-4">
          <label class="form-label">Tipo de predio</label>
          <select name="tipo_predio" class="form-select">
            <option value="Construido">Construido</option>
            <option value="Sin construir">Sin construir</option>
            <option value="Baldío">Baldío</option>
            <option value="Otro">Otro</option>
          </select>
        </div>

        <!-- Colonia -->
        <div class="col-md-4">
          <label class="form-label">Colonia</label>
          <select name="colonia" id="colonia" class="form-select" onchange="toggleOtraColonia()">
            <option value="">Seleccione una colonia</option>
            <?php
            $colonias = [ '18 de Agosto','1ro de Mayo','20 de Noviembre','6 de Junio','Alfredo del Mazo',
            'Ampliación 6 de Junio','Ampliación Acozac','Ampliación Dr. Jorge Jiménez Cantú','Ampliación Escalerillas',
            'Ampliación Loma Bonita','Ampliación Luis Córdova Reyes','Ampliación Morelos',
            'Ampliación Plutarco Elías Calles','Ampliación San Francisco','Ampliación Santo Tomás',
            'Ampliación Tejalpa','Aquiles Córdoba Morán','Ávila Camacho','Ayotla Centro','Azizintla','Benito Quezada',
            'Capillas I','Capillas II','Capillas III y IV','Cerro de Moctezuma','Citlalmina','Ciudad Cuatro Vientos',
            'Clara Córdova Morán','Coatepec','Contadero','Cumbres de la Montaña','Derramadero','Dr. Jorge Jiménez Cantú',
            'El Cacerio','El Capulín','El Caracol','El Carmen','El Chililico','El Gato','El Magueyal','El Magisterio',
            'El Mirador','El Mirto','El Molino','El Ocote','El Panteón','El Patronato','El Pilar','El Pino','El Tablón',
            'El Tejolote','Elsa Córdova Morán','Emiliano Zapata','Escalerillas','Espartaco','Estado de México','F. Álvarez',
            'Fracc. Izcalli Ixtapaluca','Fracc. Jose de la Mora','Fracc. Rancho El Carmen',
            'Fraccionamiento Unidad Deportiva Residencial Acozac','Fraternidad','Geovillas de Jesús María',
            'Geovillas de San Jacinto','Geovillas de Santa Bárbara','Geovillas Ixtapaluca 2000','Gonzalo López Cid',
            'Hornos de San Francisco','Hornos de Santa Bárbara','Hornos de Zoquiapan','Humberto Gutiérrez',
            'Humberto Vidal Mendoza','Ilhuilcamina','Independencia','Ixtapaluca Centro','Jacarandas','Jesús María',
            'José Guadalupe Posada (UPREZ)','Juan Antonio Soberanes','La Antorcha','La cañada','La Guadalupana',
            'La Huerta','La Magdalena Atlipac','La Presa','La Retama','La Venta','La Virgen',
            'Las Palmas 2da Sección','Las Palmas 3ra Etapa','Las Palmas Hacienda','Lavaderos','Lindavista','Llano Grande',
            'Loma Bonita','Loma del Rayo','Lomas de Ayotla','Lomas de Coatepec','Lomas de Ixtapaluca','Los Depósitos',
            'Los Héroes','Los Héroes Tezontle','Luis Córdova Reyes','Luis Donaldo Colosio','Manuel Serrano Vallejo',
            'Marco Antonio Sosa Balderas','Margarita Moran','Melchor Ocampo','Morelos (Nueva Independencia)',
            'Nueva Antorcha','Nueva Antorchista','Nuevo Jardín Industrial Ixtapaluca','Paseos de Coatepec',
            'Peña de la Rosa de Castilla','Piedras Grandes','Plutarco Elías Calles','Pueblo Nuevo','Rancho Guadalupe',
            'Rancho San José','Rancho Verde','Real del Campo','Residencial Ayotla','Residential Park','Rey Izcoatl',
            'Rey Izcoatl 2da Sección','Rey Izcoatl 3ra Sección','Ricardo Calva','Rigoberta Menchú','Rincón del Bosque',
            'Río Frío','Rosa de San Francisco','San Antonio Tlalpizahuac.','San Buenaventura','San Francisco Acuautla',
            'San Isidro','San Jerónimo','San José de la Palma','San Juan','San Juan San Antonio',
            'San Juan Tlalpizahuac.','San Miguel','Santa Bárbara','Santa Cruz Tlalpizahuac','Santa Cruz Tlapacoya',
            'Santo Tomás','Tecomatlan','Tejalpa','Teponaxtle','Tetitla','Tezontle','Tlacaelel','Tlapacoya Pueblo',
            'Tlayehuale','Unidad Magisterial','Valle Verde','Victorio Soto Wenceslao','Villas de Antorcha',
            'Villas de Ayotla','Volcanes','Wenceslao','Xochitenco','Zona Industrial Ayotla','Zoquiapan','Otro' ];
            foreach ($colonias as $c) {
                echo "<option value='$c'>$c</option>";
            }
            ?>
          </select>
        </div>

        <!-- Campo para otra colonia -->
        <div class="col-md-4" id="colonia_otro_div" style="display:none;">
          <label class="form-label">Especifique otra colonia</label>
          <input type="text" name="colonia_otro" id="colonia_otro" class="form-control">
        </div>

        <div class="col-md-4">
          <label class="form-label">Dirección</label>
          <input type="text" name="direccion" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Clave catastral</label>
          <input type="text" name="clave_catastral" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Base gravable</label>
          <input type="number" step="0.01" name="base_gravable" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Bimestre</label>
          <select name="bimestre" class="form-select">
            <?php for ($i=1; $i<=6; $i++): ?>
              <option value="<?= $i ?>"><?= $i ?></option>
            <?php endfor; ?>
          </select>
        </div>
        <div class="col-md-4">
          <label class="form-label">Superficie terreno </label>
          <input type="number" step="0.01" name="superficie_terreno" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Superficie construcción </label>
          <input type="number" step="0.01" name="superficie_construccion" class="form-control">
        </div>

        <!-- Contribuyente y validación -->
        <h5 class="mt-3">Contribuyente y validación</h5>
        <div class="col-md-4">
          <label class="form-label">Nombre del contribuyente</label>
          <input type="text" name="contribuyente" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Subdirector</label>
          <input type="text" name="subdirector" value="<?php echo SUBDIRECTOR; ?>" class="form-control"readonly>
        </div>
        <div class="col-md-4">
          <label class="form-label">Cargo</label>
          <input type="text" name="cargo" value="Subdirector de Recaudación" class="form-control">
        </div>

        <!-- Recibos y certificación -->
        <h5 class="mt-3">Recibos y certificación</h5>
        <div class="col-md-4">
          <label class="form-label">Recibo oficial</label>
          <input type="text" name="recibo_oficial" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Recibo mejoras</label>
          <input type="text" name="recibo_mejoras" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Costo de certificación</label>
          <input type="number" step="0.01" name="costo_certificacion" class="form-control">
        </div>

        <div class="col-12 mt-3">
          <button type="submit" name="guardar_doc" class="btn btn-primary w-100">Guardar documento</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function toggleOtraColonia() {
    const select = document.getElementById("colonia");
    const otroDiv = document.getElementById("colonia_otro_div");
    if (select.value === "Otro") {
        otroDiv.style.display = "block";
    } else {
        otroDiv.style.display = "none";
        document.getElementById("colonia_otro").value = "";
    }
}
</script>
