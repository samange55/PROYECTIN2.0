<?php
session_start();
include "config/config.php";

if (!isset($_GET["id1"]) || !isset($_GET["id2"])) {
    die("Faltan parámetros.");
}

require_once __DIR__ . '/../../../lib/fpdf/fpdf.php';
require_once __DIR__ . '/../../../lib/fpdi/src/autoload.php';

use setasign\Fpdi\Fpdi;

$pdf = new Fpdi();

// ================== PRIMER DOCUMENTO ==================
$id1 = $_GET["id1"];
$sql1 = "SELECT * FROM QRdocumentos WHERE id = ?";
$stmt1 = $conn->prepare($sql1);
$stmt1->bind_param("s", $id1);
$stmt1->execute();
$doc1 = $stmt1->get_result()->fetch_assoc();

if ($doc1) {
    $filename1 = ucfirst($doc1["tipo_documento"]) . "_" . $doc1["id"] . ".pdf";
    $path1 = __DIR__ . "/../../public/validados/" . $filename1;

    if (file_exists($path1)) {
        $pageCount = $pdf->setSourceFile($path1);
        for ($i = 1; $i <= $pageCount; $i++) {
            $tplIdx = $pdf->importPage($i);
            $pdf->AddPage();
            $pdf->useTemplate($tplIdx);
        }
    }
}

// ================== SEGUNDO DOCUMENTO ==================
$id2 = $_GET["id2"];
$sql2 = "SELECT * FROM QRdocumentos WHERE id = ?";
$stmt2 = $conn->prepare($sql2);
$stmt2->bind_param("s", $id2);
$stmt2->execute();
$doc2 = $stmt2->get_result()->fetch_assoc();

if ($doc2) {
    $filename2 = ucfirst($doc2["tipo_documento"]) . "_" . $doc2["id"] . ".pdf";
    $path2 = __DIR__ . "/../../public/validados/" . $filename2;

    if (file_exists($path2)) {
        $pageCount = $pdf->setSourceFile($path2);
        for ($i = 1; $i <= $pageCount; $i++) {
            $tplIdx = $pdf->importPage($i);
            $pdf->AddPage();
            $pdf->useTemplate($tplIdx);
        }
    }
}

// ================== SALIDA ==================
header("Content-Type: application/pdf");
header("Content-Disposition: inline; filename=Ambos_Documentos.pdf");
$pdf->Output("I", "Ambos_Documentos.pdf");
exit;
